<?php
add_action('wp_enqueue_scripts', 'salient_child_enqueue_styles', 100);

function salient_child_enqueue_styles() {
    // Enqueue jQuery UI library
    wp_enqueue_script('jqueryd-ui-core', 'https://code.jquery.com/ui/1.13.3/jquery-ui.js', array('jquery'), '1.13.3', true);
    // Enqueue jQuery UI CSS
    wp_enqueue_style('jqueryd-ui-css', 'https://code.jquery.com/ui/1.13.3/themes/base/jquery-ui.css');

    $nectar_theme_version = nectar_get_theme_version();
    wp_enqueue_style('salient-child-style', get_stylesheet_directory_uri() . '/style.css', '', $nectar_theme_version);
    
    // Enqueue Bootstrap CSS
    wp_enqueue_style('bootstrap-css', get_stylesheet_directory_uri() . '/css/bootstrap.css', array(), '5.3.3', 'all');

    // Load PM Customisations Script
    wp_register_script('urg-scrip', get_stylesheet_directory_uri() . '/js/urg-script.js', array('jquery'), '2.0', true);
    wp_enqueue_script('urg-scrip');
    wp_localize_script('urg-scrip', 'ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'user_id' => get_current_user_id()
    ));
    wp_enqueue_style('child-tsssheme-css', get_stylesheet_directory_uri() . '/css/template-style.css');
}



// Add in custom typekit font
add_filter("redux/salient_redux/field/typography/custom_fonts", "salient_redux_custom_fonts");
function salient_redux_custom_fonts($custom_fonts) {
    return array(
        'Typekit Fonts' => array(
            'neue-haas-unica, sans-serif' => "Neue Haas Unica"
        )
    );
}


// Disallow Usernames
add_filter('gettext', 'register_text');
add_filter('ngettext', 'register_text');
function register_text($translated) {
    $translated = str_ireplace('Username or Email Address', 'Email Address', $translated);
    return $translated;
}


// Checkout: save coverage + state + DoB to user mata
add_action('pmpro_after_checkout', 'custom_pmpro_save_checkout_fields');
function custom_pmpro_save_checkout_fields($user_id) {
    if (isset($_REQUEST['bdob'])) {
        update_user_meta($user_id, 'pmpro_dob', $_REQUEST['bdob']);
    }
	 if (isset($_POST['state'])) {
        update_user_meta($user_id, 'pmpro_bstate', sanitize_text_field($_POST['state']));
    }
	 if (isset($_POST['user_covrg'])) {
        update_user_meta($user_id, 'pmpro_covrg', sanitize_text_field($_POST['user_covrg']));
    }
}

// Checkout: save effective date to user meta
function my_pmpro_checkout_after_user_meta($user_id)
{
    // Check if the starting_date field is set
    if(isset($_REQUEST['starting_date'])) {
        $starting_date = sanitize_text_field($_REQUEST['starting_date']);
        // Determine the effective date based on the selected option
        if($starting_date == 'next-month') {
            $effective_date = date('mdY', strtotime('first day of next month'));
        } else { // this-month
            $effective_date = date('mdY', strtotime('first day of this month'));
        }
        // Save the effective date as user meta
        update_user_meta($user_id, 'pmpro_effectivedate', $effective_date);
    }
}
add_action('pmpro_after_checkout', 'my_pmpro_checkout_after_user_meta');



// Check-out Billing date tweak (next or current month)
add_filter("pmpro_checkout_level", "my_pmpro_checkout_level");
function my_pmpro_checkout_level($level) {
    if (!empty($_REQUEST['starting_date'] && $_REQUEST['starting_date'] == 'next-month')) {
        $level->initial_payment = $level->initial_payment - $level->billing_amount;
    }
    return $level;
}