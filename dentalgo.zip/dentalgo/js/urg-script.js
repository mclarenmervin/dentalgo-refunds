jQuery(document).ready(function ($) {
    // Constants
    const AJAX_URL = ajax_object.ajax_url;
    const USER_ID = ajax_object.user_id;

    // Datepicker Setup
    const today = new Date();
    const eighteenyears = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());

    function initializeDatepicker(selector, options) {
        if ($(selector).length) {
            $(selector).datepicker(options);
        }
    }

    initializeDatepicker("#bdob, #user_dob", {
        maxDate: eighteenyears,
        changeMonth: true,
        changeYear: true,
        yearRange: "-80:+0"
    });

    initializeDatepicker("#dependant_dob", {
        changeMonth: true,
        changeYear: true,
        yearRange: "-90:+0"
    });

    // Hide 'prev' navigation initially and hide pmpro_user_address_fields
    let currentDiv = $('.pmpro_checkout:first').show();
    $('#pmpro_user_address_fields').hide();
    if (currentDiv.css('display') === 'block') {
        $('.pmpro_checkout_gateway-stripe .pmpro-checkoutnav #prev-tab').hide();
    }

    function updateTotalAmount(selectedValue, currentAmount, totalAmount) {
        if (selectedValue === 'next-month') {
            return totalAmount - currentAmount;
        }
        return totalAmount;
    }

    // Password minimum strength
    function validatePassword() {
        const password = $('#password').val();
        const confirmPassword = $('#password2').val();

        if (password !== confirmPassword) {
            alert('Passwords do not match.');
            $('#prev-tab').hide();
            return false;
        }

        if (password.length < 8 || !/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/[0-9]/.test(password)) {
            alert('Password must be at least 8 characters long and contain a lowercase letter, an uppercase letter, and a numeric digit.');
            $('#prev-tab').hide();
            return false;
        }
        return true;
    }

    // Panel navigation
    $('#next-tab').click(function(event) {
        event.preventDefault();
        const startingDateSelect = $('#starting_date');
        const totalAmountParagraph = $('#total_amount');
        const total_amount_one = $('#total_amount_one');
        const selectedValue = startingDateSelect.val();
        const currentAmount = parseFloat(totalAmountParagraph.data('current'));
        const totalAmount = parseFloat(totalAmountParagraph.data('total'));

        const newTotal = updateTotalAmount(selectedValue, currentAmount, totalAmount);
        total_amount_one.text(`${newTotal.toFixed(2)}`);
        $('#total_amount').html('<strong>Total: </strong>$' + `${newTotal.toFixed(2)}`);
        $('.pmpro_checkout_gateway-stripe .pmpro-checkoutnav #prev-tab').show();
        $('html, body').animate({ scrollTop: 0 }, 'fast');

        let isValid = true; // Declare isValid at the start of the function

        currentDiv.find('input:visible').each(function() {
            // Skip the check for 'baddress2' if it exists
            if ($(this).attr('id') === 'baddress2') {
                return; // Continue to the next iteration without setting isValid to false
            }

            // Check for empty values for all other fields
            if ($(this).val() === '') {
                isValid = false;
                return false;
            }
        });

        if (!isValid) {
            alert('Please fill in all fields before proceeding.');
            $('#prev-tab').hide();
            return;
        }

        if ($('#pmpro_user_fields').length && !validateForm($)) {
            return;
        }

        if (currentDiv.attr('id') === 'pmpro_user_fields' && !validatePassword()) {
            return;
        }

        const bemail = $('#pmpro_form').find('#bemail').val();
        $('#pmpro_form').find('#username').val(bemail);

        currentDiv.hide();
        const currentIndex = $('.pmpro_checkout').index(currentDiv);
        currentDiv = $('.pmpro_checkout').eq(currentIndex + 1).show();

        if (currentDiv.attr('id') === 'pmpro_user_address_fields') {
            $('#pmpro_user_address_fields').show();
        } else if (currentDiv.attr('id') === 'pmpro_pricing_fields') {
            $('#pmpro_user_address_fields').hide();
        } else if (currentDiv.attr('id') === 'pmpro_payment_information_fields') {
            if ($('#terms_checkbox').prop('checked')) {
                $('.pmpro_submit').show();
                $('#next-tab').hide();
            } else {
                alert('Please accept the terms & conditions.');
                $('#prev-tab').click();
            }
        } else {
            $('.pmpro_submit').hide();
            $('#next-tab').show();
        }
    });

    $('#prev-tab').click(function(event) {
        event.preventDefault();
        $('html, body').animate({ scrollTop: 0 }, 'fast');
        currentDiv.hide();
        const currentIndex = $('.pmpro_checkout').index(currentDiv);
        currentDiv = $('.pmpro_checkout').eq(currentIndex - 1).show();

        if (currentDiv.attr('id') === 'pmpro_user_address_fields') {
            $('#pmpro_user_address_fields').show();
        } else if (currentDiv.attr('id') === 'pmpro_user_fields') {
            $('#pmpro_user_address_fields').hide();
        } else if (currentDiv.attr('id') === 'pmpro_payment_information_fields') {
            $('.pmpro_submit').show();
            $('#next-tab').hide();
        } else {
            $('.pmpro_submit').hide();
            $('#next-tab').show();
        }

        if (currentDiv.css('display') === 'block') {
            $('.pmpro_checkout_gateway-stripe .pmpro-checkoutnav #prev-tab').hide();
        }
    });

    $('body').on('change', '#pmpro_user_address_fields input, #pmpro_user_address_fields select', function() {
        var fields = {};

        $('#pmpro_user_address_fields input, #pmpro_user_address_fields select').each(function() {
            fields[$(this).attr('id')] = $(this).val();
        });

        // AJAX request to update session
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'update_session',
                fields: fields
            },
            success: function(response) {
                if (response.success) {
                    console.log(response.data);
                } else {
                    console.log('Error updating session');
                }
            }
        });
    });

    const startingPriceMsg = $('.pmpro_level_cost_text p').html();
    $('#starting_date').change(function () {
        const selectedValue = $(this).val();
        const pricePerMonth = $('.pmpro_level_cost_text strong').eq(1).text();
        if (selectedValue === 'next-month') {
            const msg = `Pay <strong>$20</strong> now, and then <strong>${pricePerMonth}</strong>`;
            $('.pmpro_level_cost_text p').html(msg);
        } else {
            $('.pmpro_level_cost_text p').html(startingPriceMsg);
        }
    });

    function fetchDependentDetails(dependentIndex) {
        $.ajax({
            url: AJAX_URL,
            type: 'POST',
            data: { action: 'fetch_dependent_details', dependent_index: dependentIndex },
            success: function (response) {
                const dependentData = response.data;
                $('#dependant_fname').val(dependentData.fname);
                $('#dependant_mname').val(dependentData.mname);
                $('#dependant_lname').val(dependentData.lname);
                $('#dependant_dob').val(dependentData.dob);
                $('#dependant_addrs1').val(dependentData.addrs1);
                // $('#dependant_addrs2').val(dependentData.addrs2);
                $('#dependant_city').val(dependentData.city);
                $('#dependant_index').val(dependentIndex);
                $('#dependant_zip').val(dependentData.zip);
                $('#dependant_title').val(dependentData.title).trigger('change');
                $('#dependant_relation').val(dependentData.relation).trigger('change');
                $('#dependant_gender').val(dependentData.gender).trigger('change');
                $('#dependant_state').val(dependentData.state).trigger('change');
                $('#add-dependant-btn').val('Update Dependent');
                const dependentFormId = 'dependant-form';
                $('html, body').animate({
                    scrollTop: $('#' + dependentFormId).offset().top
                }, 800);
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                alert('An error occurred while fetching dependent details.');
            }
        });
    }

    function validateForm($) {
        const email = $('#bemail').val();
        const confirmEmail = $('#bconfirmemail').val();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(email)) {
            alert('Please enter a valid email address');
            return false;
        }

        if (email !== confirmEmail) {
            alert('Email addresses do not match');
            return false;
        }
        return true;
    }

    $(document).on('click', '.edit-dependent', function () {
        const dependentIndex = $(this).data('dependent-user-id');
        fetchDependentDetails(dependentIndex);
    });

    $('#add-dependant-btn').click(function (event) {
        const dependant = {
            title: $('#dependant_title').val(),
            fname: $('#dependant_fname').val(),
            mname: $('#dependant_mname').val(),
            lname: $('#dependant_lname').val(),
            relation: $('#dependant_relation').val(),
            dob: $('#dependant_dob').val(),
            addrs1: $('#dependant_addrs1').val(),
            addrs2: $('#dependant_addrs2').val(),
            city: $('#dependant_city').val(),
            state: $('#dependant_state').val(),
            zip: $('#dependant_zip').val(),
            uid: $('#dependant_uid').val(),
            sqno: $('#dependant_sqno').val(),
            covrg: $('#dependant_covrg').val(),
            gc: $('#dependant_gc').val(),
            gender: $('#dependant_gender').val(),
        };

        const validation = {
            fname: $('#dependant_fname').val(),
            lname: $('#dependant_lname').val(),
            relation: $('#dependant_relation').val(),
            dob: $('#dependant_dob').val(),
            addrs1: $('#dependant_addrs1').val(),
            city: $('#dependant_city').val(),
            state: $('#dependant_state').val(),
            zip: $('#dependant_zip').val(),
            gender: $('#dependant_gender').val(),
        };

        for (const key in validation) {
            if (validation.hasOwnProperty(key)) {
                if (!validation[key]) {
                    alert(`Please enter a valid ${key.replace('_', ' ')}.`);
                    return;
                }
            }
        }

        const index = $('#dependant_index').val();
        $('#spinner').html('<i class="fa fa-spinner fa-spin"></i>');

        $.ajax({
            url: AJAX_URL,
            type: 'POST',
            data: {
                action: 'add_dependent',
                dependant: dependant,
                index: index,
            },
            success: function (response) {
                $('#spinner').html('');
                $('#message').html('<p>' + response.data + '</p>').show().delay(3000).fadeOut();
                location.reload();
            },
            error: function (xhr) {
                $('#spinner').html('');
                console.error(xhr.responseText);
                alert('An error occurred. Please try again later.');
            }
        });
    });

    $('.remove-dependent').on('click', function () {
        const dependentUserId = $(this).data('dependent-user-id');
        const $dependentLi = $(this).closest('li');

        $.ajax({
            url: AJAX_URL,
            type: 'POST',
            data: {
                action: 'remove_dependent_user',
                user_id: USER_ID,
                dependent_id: dependentUserId
            },
            success: function () {
                $dependentLi.remove();
                location.reload();
            },
            error: function (xhr) {
                console.error(xhr.responseText);
            }
        });
    });

    $('#cancel-plan-btn').click(function () {
        $.ajax({
            url: AJAX_URL,
            type: 'POST',
            data: {
                action: 'delete_plan',
            },
            success: function () {
                location.reload();
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                alert('An error occurred. Please try again later.');
            }
        });
    });

    const maxDate = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
    const formattedMaxDate = maxDate.toISOString().split('T')[0];
    $('#user_dob').attr('max', formattedMaxDate);

    $('body').on('click', '#update-profile-btn', function () {
        const user_details = {
            title: $('#title').val(),
            fname: $('#first_name').val(),
            mname: $('#middle_name').val(),
            lname: $('#last_name').val(),
            email: $('#user_email').val(),
            post: $('#user_postname').val(),
            address_line1: $('#address_line1').val(),
            address_line2: $('#address_line2').val(),
            address_city: $('#address_city').val(),
            state: $('#state').val(),
            address_zip: $('#address_zip').val(),
            address_zip4: $('#address_zip4').val(),
            uid: $('#user_uid').val(),
            sqno: $('#user_sqno').val(),
            covrg: $('#user_covrg').val(),
            gc: $('#user_gc').val(),
            phone: $('#user_phone').val(),
            dob: $('#user_dob').val(),
            gender: $('#user_gender').val(),
        };

        const requiredFields = {
            fname: $('#first_name').val(),
            lname: $('#last_name').val(),
            email: $('#user_email').val(),
            address_line1: $('#address_line1').val(),
            address_city: $('#address_city').val(),
            state: $('#state').val(),
            address_zip: $('#address_zip').val(),
            dob: $('#user_dob').val(),
            gender: $('#user_gender').val(),
        };

        for (const key in requiredFields) {
            if (requiredFields.hasOwnProperty(key) && !requiredFields[key]) {
                alert(`Please enter a valid ${key.replace('_', ' ')}.`);
                return;
            }
        }

        $.ajax({
            url: AJAX_URL,
            type: 'POST',
            data: {
                action: 'update_user',
                user_details: user_details
            },
            success: function () {
                location.reload();
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                alert('An error occurred. Please try again later.');
            }
        });
    });
	
	

    // Function to automatically format the date with slashes
    function formatDOB(input) {
        // Remove any non-digit characters
        let dob = input.val().replace(/\D/g, '');

        // If the length is more than 2, add a slash after the first 2 digits
        if (dob.length > 2) {
            dob = dob.slice(0, 2) + '/' + dob.slice(2);
        }

        // If the length is more than 5, add another slash after the month digits
        if (dob.length > 5) {
            dob = dob.slice(0, 5) + '/' + dob.slice(5);
        }

        // Set the formatted value back to the input field
        input.val(dob);
    }

    // Attach event listeners to date of birth input fields
    $('#bdob, #user_dob').on('input', function() {
        formatDOB($(this));
    });
	
});
