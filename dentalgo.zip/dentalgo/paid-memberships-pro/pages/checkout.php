<?php
global $gateway, $pmpro_review, $skip_account_fields, $pmpro_paypal_token, $wpdb, $current_user, $pmpro_msg, $pmpro_msgt, $pmpro_requirebilling, $pmpro_level, $pmpro_levels, $tospage, $pmpro_show_discount_code, $pmpro_error_fields, $pmpro_default_country;
global $discount_code, $password, $password2, $username, $bfirstname, $blastname, $baddress1, $baddress2, $bcity, $bstate, $bzipcode, $bcountry, $bphone, $befname, $belname, $bemail, $bconfirmemail, $bdob, $CardType, $AccountNumber, $ExpirationMonth,$ExpirationYear;

/**
 * Filter to set if PMPro uses email or text as the type for email field inputs.
 *
 * @since 1.8.4.5
 *
 * @param bool $use_email_type, true to use email type, false to use text type
 */
$pmpro_email_field_type = apply_filters('pmpro_email_field_type', true);

// Set the wrapping class for the checkout div based on the default gateway;
$default_gateway = pmpro_getOption( 'gateway' );
if ( empty( $default_gateway ) ) {
	$pmpro_checkout_gateway_class = 'pmpro_checkout_gateway-none';
} else {
	$pmpro_checkout_gateway_class = 'pmpro_checkout_gateway-' . $default_gateway;
} 
?>



<?php //do_action('pmpro_checkout_before_form');?>

<div id="pmpro_level-<?php echo intval( $pmpro_level->id ); ?>" class="<?php echo esc_attr( pmpro_get_element_class( $pmpro_checkout_gateway_class, 'pmpro_level-' . $pmpro_level->id ) ); ?>">
<form id="pmpro_form" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_form' ) ); ?>" action="<?php if(!empty($_REQUEST['review'])) echo esc_url( pmpro_url("checkout", "?level=" . $pmpro_level->id) ); ?>" method="post">

	<input type="hidden" id="level" name="level" value="<?php echo esc_attr($pmpro_level->id) ?>" />
	<input type="hidden" id="checkjavascript" name="checkjavascript" value="1" />
<?php if ($discount_code && $pmpro_review) { ?>
				<input class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_alter_price', 'pmpro_discount_code' ) ); ?>" id="pmpro_discount_code" name="pmpro_discount_code" type="hidden" value="<?php echo esc_attr($discount_code) ?>" />
			<?php } ?>

	<?php if($pmpro_msg) { ?>
		<div role="alert" id="pmpro_message" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_message ' . $pmpro_msgt, $pmpro_msgt ) ); ?>">
			<?php echo wp_kses_post( apply_filters( 'pmpro_checkout_message', $pmpro_msg, $pmpro_msgt ) ); ?>
		</div>
	<?php } else { ?>
		<div id="pmpro_message" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_message' ) ); ?>" style="display: none;"></div>
	<?php } ?>

	<?php if($pmpro_review) { ?>
		<p><?php echo wp_kses( __( 'Almost done. Review the membership information and pricing below then <strong>click the "Complete Payment" button</strong> to finish your order.', 'paid-memberships-pro' ), array( 'strong' => array() ) ); ?></p>
	<?php } ?>

	<?php if(!$skip_account_fields && !$pmpro_review) { ?>

	<?php 
		// Get discount code from URL parameter, so if the user logs in it will keep it applied.
		$discount_code_link = !empty( $discount_code) ? '&discount_code=' . $discount_code : ''; 
	?>
	<!-- start of  user information section -->
	<div id="pmpro_user_fields" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout', 'pmpro_user_fields' ) ); ?>">
	  	<h4 class="pmpro-h4">DentalGo Registration</h4>
		<h2 class="pmpro-h2">
			<span class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-h2-name' ) ); ?>"><?php esc_html_e('Welcome!', 'paid-memberships-pro' );?></span>
			<span class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-h2-msg' ) ); ?>"><?php esc_html_e('Already have an account?', 'paid-memberships-pro' );?> <a href="<?php echo esc_url( wp_login_url( apply_filters( 'pmpro_checkout_login_redirect', pmpro_url("checkout", "?level=" . $pmpro_level->id . $discount_code_link) ) ) ); ?>"><?php esc_html_e('Log in here', 'paid-memberships-pro' );?></a></span>
		</h2>
		<!-- end pmpro_checkout-field-username -->
		<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-fields' ) ); ?>">
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-username', 'pmpro_checkout-field-username' ) ); ?>">
					<label for="username"><?php esc_html_e('Username', 'paid-memberships-pro' );?></label>
					<input id="username" name="username" type="text" class="<?php echo esc_attr( pmpro_get_element_class( 'input', 'username' ) ); ?>" size="30" value="<?php echo esc_attr($username); ?>" />
			</div>
		
			<?php
				do_action('pmpro_checkout_after_username');
 			?>
		
	
	<?php 
	// Use level ID to determine coverage level. 2 + 4 are family plans, 1+3 single plans;
    $plan_id = $pmpro_level->id; // Assign $plan_id from $pmpro_level->id
    $user_covrg = 'MO'; // Default coverage
    if ($plan_id == 2 || $plan_id == 4) {
        $user_covrg = 'MF';
    }
?>
		<input type="hidden" name="user_covrg" id="user_covrg" value="<?php echo esc_attr($user_covrg); ?>">
				
		<div class="checkout-formfield-wrapper single">
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-starting-date', 'pmpro_checkout-field-starting-date' ) ); ?>">
				<p class="starting-date-text">
					<?php esc_html_e('When would you like your membership plan to start?', 'paid-memberships-pro' ); ?>
				</p>
				<div class="dg-tooltip">
					<i class="fas fa-info-circle"></i>
					<span class="tooltiptext"><?php esc_html_e('Please note there is a 48-72 hour delay between registration and account activation', 'paid-memberships-pro' ); ?></span>
				</div>
					
				<div class="form-floating">
					<select name="starting_date" id="starting_date" class="form-select">
						<option value="next-month">First of <?php echo date('F Y', strtotime('first day of next month')); ?></option>
						<option value="this-month">First of <?php echo date('F Y', strtotime('first day of this month')); ?></option>
					</select>
					<label for="starting_date">Start Date</label>
				</div>
			</div>
		</div>
				
		<div class="checkout-formfield-wrapper double">
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-bfirstname', 'pmpro_checkout-field-bfirstname' ) ); ?>">
				<div class="form-floating">
  				<input type="text" name="bfirstname"  size="30" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'input', 'bfirstname' ) ); ?>" id="bfirstname" value="<?php echo esc_attr($bfirstname); ?>" placeholder="First name"/>
  				<label for="bfirstname"><?php esc_html_e('First Name', 'paid-memberships-pro' );?></label>
			</div>
		</div> <!-- end pmpro_checkout-field-bfirstname -->
				
		<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-blastname', 'pmpro_checkout-field-blastname' ) ); ?>">
			<div class="form-floating">
				<input id="blastname" name="blastname" type="text" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'input', 'blastname' ) ); ?>" size="30" value="<?php echo esc_attr($blastname); ?>" placeholder="Last name"/>
				<label for="blastname"><?php esc_html_e('Last Name', 'paid-memberships-pro' );?></label>
			</div> 
		</div><!-- end pmpro_checkout-field-blastname --> 
	</div>
		
		<div class="checkout-formfield-wrapper single">		
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-bdob', 'pmpro_checkout-field-bdob' ) ); ?>">
				<div class="form-floating">
					<input id="bdob" name="bdob" type="text" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'input', 'bdob' ) ); ?>" size="30" value="<?php echo esc_attr($bdob); ?>" placeholder="Date of Birth"/>
					<label for="bdob"><?php esc_html_e('Date of Birth', 'paid-memberships-pro' );?></label>
				</div>
			</div>
		</div>
		

			<div class="checkout-formfield-wrapper double">
				<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-bemail', 'pmpro_checkout-field-bemail' ) ); ?>">
					<div class="form-floating">
						<input id="bemail" name="bemail" type="<?php echo ($pmpro_email_field_type ? 'email' : 'text'); ?>" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'input', 'bemail' ) ); ?>" size="30" value="<?php echo esc_attr($bemail); ?>" maxlength="64" placeholder="E-mail address"/>
						<label for="bemail"><?php esc_html_e('Email Address', 'paid-memberships-pro' );?></label>
					</div>
				</div> <!-- end pmpro_checkout-field-bemail -->

				<?php
					$pmpro_checkout_confirm_email = apply_filters("pmpro_checkout_confirm_email", true);
					if($pmpro_checkout_confirm_email) { ?>
						<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-bconfirmemail', 'pmpro_checkout-field-bconfirmemail' ) ); ?>">
							<div class="form-floating">
								<input id="bconfirmemail" name="bconfirmemail" type="<?php echo ($pmpro_email_field_type ? 'email' : 'text'); ?>" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'input', 'bconfirmemail' ) ); ?>" size="30" value="<?php echo esc_attr($bconfirmemail); ?>" maxlength="64" placeholder="Confirm E-mail"/>
								<label for="bconfirmemail"><?php esc_html_e('Confirm Email Address', 'paid-memberships-pro' );?></label>
							</div>
						</div> <!-- end pmpro_checkout-field-bconfirmemail -->
						</div>
					<?php } else { ?>
						<input type="hidden" name="bconfirmemail_copy" value="1" />
					<?php }
				?>

				<?php
					do_action('pmpro_checkout_after_email');
				?>

			<div class="checkout-formfield-wrapper double">
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-password', 'pmpro_checkout-field-password' ) ); ?>">
				<div class="form-floating">
					<input id="password" name="password" type="password" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'password' ) ); ?>" size="30" autocomplete="new-password" placeholder="Create a password"/>
					<label for="password"><?php esc_html_e('Password', 'paid-memberships-pro' );?></label>
				</div>
			</div> <!-- end pmpro_checkout-field-password -->

			<?php
				$pmpro_checkout_confirm_password = apply_filters("pmpro_checkout_confirm_password", true);
				if($pmpro_checkout_confirm_password) { ?>
					<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-password2', 'pmpro_checkout-field-password2' ) ); ?>">
						<div class="form-floating">
						<input id="password2" name="password2" type="password" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'input', 'password2' ) ); ?>" size="30" autocomplete="new-password" placeholder="Confirm password"/>
						<label for="password2"><?php esc_html_e('Confirm Password', 'paid-memberships-pro' );?></label>
						</div>
					</div> <!-- end pmpro_checkout-field-password2 -->
					</div>
				<?php } else { ?>
					<input type="hidden" name="password2_copy" value="1" />
				<?php }
			?>

			<?php
				do_action('pmpro_checkout_after_password');
			?>
			
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_hidden' ) ); ?>">
				<label for="fullname"><?php esc_html_e('Full Name', 'paid-memberships-pro' );?></label>
				<input id="fullname" name="fullname" type="text" class="<?php echo esc_attr( pmpro_get_element_class( 'input', 'fullname' ) ); ?>" size="30" value="" autocomplete="off"/> <strong><?php esc_html_e('LEAVE THIS BLANK', 'paid-memberships-pro' );?></strong>
			</div> <!-- end pmpro_hidden -->

		</div>  <!-- end pmpro_checkout-fields -->
	</div> <!-- end pmpro_user_fields -->
	<?php } elseif($current_user->ID && !$pmpro_review) { ?>
		<div id="pmpro_account_loggedin" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_message pmpro_alert', 'pmpro_account_loggedin' ) ); ?>">
			<?php
				$allowed_html = array(
					'a' => array(
						'href' => array(),
						'title' => array(),
						'target' => array(),
					),
					'strong' => array(),
				);
				echo wp_kses( sprintf( __('You are logged in as <strong>%s</strong>. If you would like to use a different account for this membership, <a href="%s">log out now</a>.', 'paid-memberships-pro' ), $current_user->user_login, wp_logout_url( esc_url_raw( $_SERVER['REQUEST_URI'] ) ) ), $allowed_html );
			?>
		</div> <!-- end pmpro_account_loggedin -->
	<?php } ?>
	<!-- end  user information section -->
	<?php
		do_action('pmpro_checkout_after_user_fields');
	?>

	<div id="pmpro_user_address_fields" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout', 'pmpro_user_address_fields' ) ); ?>" style="display: none;">
		<h4 class="pmpro-h4">DentalGo Registration</h4>
			<h2 class="pmpro-h2">
				<span class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-h2-name' ) ); ?>"><?php esc_html_e('Address Details', 'paid-memberships-pro' );?></span>
				
			</h2>
    <div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_card' ) ); ?>">
        <div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_card_content' ) ); ?>">
            <div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_fields pmpro_cols-2' ) ); ?>">

				<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-fields' ) ); ?>">
                <!-- Address 1 -->
				<div class="checkout-formfield-wrapper single">
				<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-baddresss1', 'pmpro_checkout-field-beddresss1' ) ); ?>">
				<p class="address-details-text">
				<?php esc_html_e('Please fill in the account holder\'s address details.', 'paid-memberships-pro' ); ?>
				</p>
                <div class="form-floating mb-3 <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_field pmpro_form_field-text pmpro_form_field-baddress1', 'pmpro_form_field-baddress1' ) ); ?>">
                    <input id="baddress1" name="pmpro_baddress1" type="text" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_input pmpro_form_input-text', 'baddress1' ) ); ?>" placeholder="<?php esc_attr_e('Address line 1', 'paid-memberships-pro'); ?>" />
                    <label for="baddress1"><?php esc_html_e('Address line 1', 'paid-memberships-pro' );?></label>
				</div>
                </div> <!-- end pmpro_form_field-baddress1 -->
				</div>

                <!-- Address 2 -->
				<div class="checkout-formfield-wrapper single">
				<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-baddresss2', 'pmpro_checkout-field-baddresss2' ) ); ?>">	
                <div class="form-floating mb-3 <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_field pmpro_form_field-text pmpro_form_field-baddress2', 'pmpro_form_field-baddress2' ) ); ?>">
                    <input id="baddress2" name="pmpro_baddress2" type="text" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_input pmpro_form_input-text', 'baddress2' ) ); ?>" placeholder="<?php esc_attr_e('Address line 2', 'paid-memberships-pro'); ?>" />
                    <label for="baddress2"><?php esc_html_e('Address line 2', 'paid-memberships-pro' );?></label>
				</div>
				</div> <!-- end pmpro_form_field-baddress2 -->
				</div>

                <!-- City -->
				<div class="checkout-formfield-wrapper single">		
				<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-bcity', 'pmpro_checkout-field-ecity' ) ); ?>">
                <div class="form-floating mb-3 <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_field pmpro_form_field-text pmpro_form_field-bcity', 'pmpro_form_field-bcity' ) ); ?>">
                    <input id="bcity" name="pmpro_bcity" type="text" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_input pmpro_form_input-text', 'bcity' ) ); ?>" placeholder="<?php esc_attr_e('City', 'paid-memberships-pro'); ?>" />
                    <label for="bcity"><?php esc_html_e('City', 'paid-memberships-pro' );?></label>
				</div>
				</div> <!-- end pmpro_form_field-bcity -->
				</div>

                <!-- State -->
                <div class="checkout-formfield-wrapper single">
				<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-bstate', 'pmpro_checkout-field-bstate' ) ); ?>">
				<div class="form-floating mb-3 <?php echo esc_attr(pmpro_get_element_class('pmpro_form_field pmpro_form_field-select pmpro_form_field-bstate', 'pmpro_form_field-bstate')); ?>">
                    <select id="state" class="form-select <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_input pmpro_form_input-select', 'bstate' ) ); ?>" name="pmpro_bstate" aria-label="Select your state">
                        <?php
                        // Array of all US states with abbreviations
                        $us_states = array(
                            "AL" => "Alabama",
                            "AK" => "Alaska",
                            "AZ" => "Arizona",
                            "AR" => "Arkansas",
                            "CA" => "California",
                            "CO" => "Colorado",
                            "CT" => "Connecticut",
                            "DE" => "Delaware",
                            "FL" => "Florida",
                            "GA" => "Georgia",
                            "HI" => "Hawaii",
                            "ID" => "Idaho",
                            "IL" => "Illinois",
                            "IN" => "Indiana",
                            "IA" => "Iowa",
                            "KS" => "Kansas",
                            "KY" => "Kentucky",
                            "LA" => "Louisiana",
                            "ME" => "Maine",
                            "MD" => "Maryland",
                            "MA" => "Massachusetts",
                            "MI" => "Michigan",
                            "MN" => "Minnesota",
                            "MS" => "Mississippi",
                            "MO" => "Missouri",
                            "MT" => "Montana",
                            "NE" => "Nebraska",
                            "NV" => "Nevada",
                            "NH" => "New Hampshire",
                            "NJ" => "New Jersey",
                            "NM" => "New Mexico",
                            "NY" => "New York",
                            "NC" => "North Carolina",
                            "ND" => "North Dakota",
                            "OH" => "Ohio",
                            "OK" => "Oklahoma",
                            "OR" => "Oregon",
                            "PA" => "Pennsylvania",
                            "RI" => "Rhode Island",
                            "SC" => "South Carolina",
                            "SD" => "South Dakota",
                            "TN" => "Tennessee",
                            "TX" => "Texas",
                            "UT" => "Utah",
                            "VT" => "Vermont",
                            "VA" => "Virginia",
                            "WA" => "Washington",
                            "WV" => "West Virginia",
                            "WI" => "Wisconsin",
                            "WY" => "Wyoming"
                        );

                        // States to exclude
                        $exclude_states = array("VT", "UT", "WA");

                        // Loop through each state and add to dropdown if not in exclude list
                        foreach ($us_states as $abbr => $state) {
                            if (!in_array($abbr, $exclude_states)) {
                                $selected = ($abbr == $bstate) ? "selected" : "";
                                echo "<option value=\"$abbr\" $selected >$state</option>";
                            }
                        }
                        ?>
                    </select>
                    <label for="state"><?php esc_html_e('State', 'paid-memberships-pro'); ?></label>
				</div>
				</div> <!-- end pmpro_form_field-bstate -->
				</div>

                <!-- Postal Code -->
                <div class="checkout-formfield-wrapper single">
				<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-bzipcode', 'pmpro_checkout-field-bzipcode' ) ); ?>">
				<div class="form-floating mb-3 <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_field pmpro_form_field-text pmpro_form_field-bzipcode', 'pmpro_form_field-bzipcode' ) ); ?>">
                    <input id="bzipcode" name="pmpro_bzipcode" type="text" class="form-control <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_input pmpro_form_input-text', 'bzipcode' ) ); ?>" placeholder="<?php esc_attr_e('Zip', 'paid-memberships-pro'); ?>" />
                    <label for="bzipcode"><?php esc_html_e('Zip', 'paid-memberships-pro' );?></label>
                </div> <!-- end pmpro_form_field-bzipcode -->
				</div>
				</div>
				
               <!-- Country -->
                <?php
                $show_country = apply_filters("pmpro_international_addresses", false);
                if ($show_country) { ?>
                    <div class="form-floating mb-3 <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_field pmpro_form_field-select pmpro_form_field-bcountry', 'pmpro_form_field-bcountry' ) ); ?>">
                        <select name="pmpro_bcountry" id="bcountry" class="form-select <?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_input pmpro_form_input-select', 'bcountry' ) ); ?>">
                            <?php
                            global $pmpro_countries, $pmpro_default_country;
                            if (!$bcountry) {
                                $bcountry = $pmpro_default_country;
                            }
                            foreach ($pmpro_countries as $abbr => $country) { ?>
                                <option value="<?php echo esc_attr($abbr) ?>" <?php if ($abbr == $bcountry) { ?>selected="selected"<?php } ?>><?php echo esc_html($country) ?></option>
                            <?php } ?>
                        </select>
                        <label for="bcountry"><?php esc_html_e('Country', 'paid-memberships-pro' );?></label>
                    </div> <!-- end pmpro_form_field-bcountry -->
                <?php } else { ?>
				<input type="hidden" name="bcountry" id="bcountry" value="<?php echo esc_attr( $pmpro_default_country ); ?>" />
                <?php } ?>
					
				</div>
            </div> <!-- end pmpro_form_fields -->
        </div> <!-- end pmpro_card_content -->
    </div> <!-- end pmpro_card -->
</div> <!-- end pmpro_user_address_fields -->

	<?php
		$include_pricing_fields = apply_filters( 'pmpro_include_pricing_fields', true );
		global $current_user;
		$current_user->membership_level = pmpro_getMembershipLevelForUser($current_user->ID);
		$hasMembership = pmpro_getMembershipLevelForUser($current_user->ID);
		$old_level = $current_user->membership_level->id;
		if ( $include_pricing_fields ) {
		?>
		<!--  -->
		
		<div id="pmpro_pricing_fields" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout', 'pmpro_pricing_fields' ) ); ?>">
			<h4 class="pmpro-h4">DentalGo Registration</h4>
			<h2 class="pmpro-h2">
				<span class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-h2-name' ) ); ?>"><?php esc_html_e('Order Summary', 'paid-memberships-pro' );?></span>
				
			</h2>
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-fields' ) ); ?>">
			<div class="order-details pmpro">
				<p id="plan-selected"><strong>Selected Plan: </strong><?php echo $pmpro_level->name; ?><?php if(count($pmpro_levels) > 1) { ?><span class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-h2-msg change-plan' ) ); ?>"><a aria-label="<?php esc_html_e( 'Select a different membership level', 'paid-memberships-pro' ); ?>" href="https://dentalgo.com/#start"><?php esc_html_e('Change Plan', 'paid-memberships-pro' );?></a></span><?php } ?></p><br>
				<p><strong>Payment frequency: </strong><?php echo $pmpro_level->cycle_period; ?></p>
				<p id="current-price"><strong>Price:</strong> <?php echo '$'. round($pmpro_level->billing_amount, 2) .' per '. $pmpro_level->cycle_period; ?></p>
				<p id="discounted-text"></p>
				<?php 
				if($hasMembership) {
					$total = floatval($pmpro_level->billing_amount);
				} else {
					$total = 20 + floatval($pmpro_level->billing_amount);
					$main_amount = floatval($pmpro_level->billing_amount);
					
					if($pmpro_level->cycle_period == "Month") {
						$months_to_add = 1;
					} else if($pmpro_level->cycle_period == "Year") {
						$months_to_add = 12;
					}
					
					$date = new DateTime();
					$date->modify("+$months_to_add month");
					
					if($pmpro_level->cycle_period == "year") {
						$date->modify('+1 year');
					}
					
					$month = date_i18n('F', $date->getTimestamp());
					$year = $date->format('Y');

					?>
					<p id="current-refundable"><strong>One time, non-refundable processing fee:</strong> $20</p><br>
				<p><strong>Payment Summary:</strong><br>Pay <strong id="total_amount_one_main">$<span id="total_amount_one"><? echo $total; ?></span> today</strong> and <strong id="billing_amount">$<? echo $main_amount; ?></strong> 1st of <?php echo $month ." ".$year; ?></p>
					<?php
				}
				
				?>
				<p id="total_amount" data-old="<?php echo $old_level; ?>" data-new="<?php echo $pmpro_level->id; ?>" data-current="<?php echo round($pmpro_level->billing_amount, 2); ?>" data-total="<?php echo 20 + floatval($pmpro_level->billing_amount); ?>"><strong>Total: </strong>
				<?php echo '$'.$total; ?></p>
				
				<?php if($discount_code && pmpro_checkDiscountCode($discount_code)) { ?>
								<?php
									echo '<p class="' . esc_attr( pmpro_get_element_class( 'pmpro_level_discount_applied' ) ) . '">';
									echo sprintf( esc_html__( 'The %s code has been applied to your order.', 'paid-memberships-pro' ), '<span class="' . esc_attr( pmpro_get_element_class( "pmpro_tag pmpro_tag-discount-code", "pmpro_tag-discount-code" ) ) . '">' . esc_html( $discount_code ) . '</span>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
									echo '</p> <!-- end pmpro_level_discount_applied -->';
								?>
							<?php } ?>
				
				
			</div>
				
			<div class="dg-terms">
			<input type="checkbox" id="terms_checkbox" name="terms_checkbox">
    		<label for="terms_checkbox">I accept the <a target="_blank" href="https://dentalgo.com/terms-conditions/">DentalGo terms &amp; conditions</a></label>
			</div>
				
			
				

 				</div> <!-- end #pmpro_level_cost -->

				<?php do_action("pmpro_checkout_after_level_cost"); ?>

				<?php if ( $pmpro_show_discount_code ) { ?>
						<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_card_actions' ) ); ?>">
							<?php if($discount_code && !$pmpro_review) { ?>
								<span id="other_discount_code_p"><button type="button" id="other_discount_code_toggle"><?php esc_html_e('Click here to change your discount code', 'paid-memberships-pro' );?></button></span>
							<?php } elseif(!$pmpro_review) { ?>
								<span id="other_discount_code_p"><?php esc_html_e('Do you have a discount code?', 'paid-memberships-pro' );?> <button type="button" id="other_discount_code_toggle"><?php esc_html_e('Click here to enter your discount code', 'paid-memberships-pro' );?></button></span>
							<?php } elseif($pmpro_review && $discount_code) { ?>
								<span><strong><?php esc_html_e('Discount Code', 'paid-memberships-pro' );?>:</strong> <?php echo esc_html( $discount_code ); ?></span>
							<?php } ?>
							<div id="other_discount_code_fields" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_field pmpro_form_field-text' ) ); ?>" style="display: none;">
								<label for="pmpro_other_discount_code" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_label' ) ); ?>"><?php esc_html_e('Discount Code', 'paid-memberships-pro' );?></label>
								<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_fields-inline' ) ); ?>">
									<input id="pmpro_other_discount_code" name="pmpro_other_discount_code" type="text" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_form_input pmpro_form_input-text pmpro_alter_price', 'other_discount_code' ) ); ?>" value="<?php echo esc_attr($discount_code); ?>" />
									<input aria-label="<?php esc_html_e( 'Apply discount code', 'paid-memberships-pro' ); ?>" type="button" name="other_discount_code_button" id="other_discount_code_button" value="<?php esc_attr_e('Apply', 'paid-memberships-pro' );?>" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_btn pmpro_btn-submit-discount-code', 'other_discount_code_button' ) ); ?>" />
								</div>
							</div>
						</div> <!-- end pmpro_card_actions -->
					<?php } ?>
				</div> <!-- end pmpro_pricing_fields -->
				<?php
				} // if ( $include_pricing_fields )
			?>

	<?php
		do_action('pmpro_checkout_after_pricing_fields');
	?>

	
	 	 

	<?php do_action("pmpro_checkout_after_billing_fields"); ?>


	<?php
		$pmpro_accepted_credit_cards = pmpro_getOption("accepted_credit_cards");
		$pmpro_accepted_credit_cards = explode(",", $pmpro_accepted_credit_cards);
		$pmpro_accepted_credit_cards_string = pmpro_implodeToEnglish($pmpro_accepted_credit_cards);
	?>
	
	<?php
	// $pmpro_include_payment_information_fields = apply_filters("pmpro_include_payment_information_fields",  true);
	//global vars
	global $pmpro_requirebilling, $pmpro_show_discount_code, $discount_code, $CardType, $AccountNumber, $ExpirationMonth, $ExpirationYear;

	//include ours
	?>
	<div id="pmpro_payment_information_fields" class="customised-payment-field <?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout', 'pmpro_payment_information_fields' ) ); ?>"
			<?php if ( ! $pmpro_requirebilling || apply_filters( "pmpro_hide_payment_information_fields", false ) ) { ?>style="display: none;"<?php } ?>>
		<h4 class="pmpro-h4">DentalGo Registration</h4>
		<h2>
			<span class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-h2-name' ) ); ?>"><?php esc_html_e( 'Payment Information', 'paid-memberships-pro' ); ?></span>
			
		</h2>
		<?php $sslseal = get_option( "pmpro_sslseal" ); ?>
		<?php if ( ! empty( $sslseal ) ) { ?>
		<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-fields-hide-seal' ) ); ?>">
			<?php } ?>
		<?php
		if ( get_option( 'pmpro_stripe_payment_request_button' ) ) { ?>
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_checkout-field-payment-request-button', 'pmpro_checkout-field-payment-request-button' ) ); ?>">
				<div id="payment-request-button"><!-- Alternate payment method will be inserted here. --></div>
				<h4 class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_payment-credit-card', 'pmpro_payment-credit-card' ) ); ?>">
					<?php
					echo esc_html( pmpro_is_checkout() ? __( 'Pay with Credit Card', 'paid-memberships-pro' ) : __( 'Credit Card', 'paid-memberships-pro' ) );					
					?>
				</h4>
			</div>
			<?php
		}
		?>
		<div class="pmpro_checkout-fields<?php if ( ! empty( $sslseal ) ) { ?> pmpro_checkout-fields-leftcol<?php } ?>">
			<input type="hidden" id="CardType" name="CardType"
					value="<?php echo esc_attr( $CardType ); ?>"/>
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_payment-account-number', 'pmpro_payment-account-number' ) ); ?>">
				<label for="AccountNumber"><?php esc_html_e( 'Card Number', 'paid-memberships-pro' ); ?></label>
				<div id="AccountNumber"></div>
			</div>
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_payment-expiration', 'pmpro_payment-expiration' ) ); ?>">
				<label for="Expiry"><?php esc_html_e( 'Expiration Date', 'paid-memberships-pro' ); ?></label>
				<div id="Expiry"></div>
			</div>
			<?php
			$pmpro_show_cvv = apply_filters( "pmpro_show_cvv", true );
			if ( $pmpro_show_cvv ) { ?>
				<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_payment-cvv', 'pmpro_payment-cvv' ) ); ?>">
					<label for="CVV"><?php esc_html_e( 'CVC', 'paid-memberships-pro' ); ?></label>
					<div id="CVV"></div>
				</div>
			<?php } ?>
			<?php if ( $pmpro_show_discount_code ) { ?>
				<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_payment-discount-code', 'pmpro_payment-discount-code' ) ); ?>">
					<label for="pmpro_discount_code"><?php esc_html_e( 'Discount Code', 'paid-memberships-pro' ); ?></label>
					<input class="<?php echo esc_attr( pmpro_get_element_class( 'input pmpro_alter_price', 'pmpro_discount_code' ) ); ?>"
							id="pmpro_discount_code" name="pmpro_discount_code" type="text" size="10"
							value="<?php echo esc_attr( $discount_code ) ?>"/>
					<input aria-label="<?php esc_html_e( 'Apply discount code', 'paid-memberships-pro' ); ?>" type="button" id="discount_code_button" name="discount_code_button"
							value="<?php esc_attr_e( 'Apply', 'paid-memberships-pro' ); ?>"/>
					<p id="discount_code_message" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_message' ) ); ?>" style="display: none;"></p>
				</div>
			<?php } ?>
		</div> <!-- end pmpro_checkout-fields -->
		<?php if ( ! empty( $sslseal ) ) { ?>
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-fields-rightcol pmpro_sslseal', 'pmpro_sslseal' ) ); ?>">
				<?php
				// This value is set by admins and could contain JS. Will be replaced with a hook in future versions.
				//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo stripslashes( $sslseal );
				?>
			</div>
		</div> <!-- end pmpro_checkout-fields-display-seal -->
	<?php } ?>
	</div> <!-- end pmpro_payment_information_fields -->

	<?php do_action('pmpro_checkout_after_payment_information_fields'); ?>
	<?php if($tospage && !$pmpro_review) { ?>
		<div id="pmpro_tos_fields" class="<?php echo  ( pmpro_get_element_class( 'pmpro_checkout', 'pmpro_tos_fields' ) ); ?>">
			<hr />
			<h2>
				<span class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-h2-name' ) ); ?>"><?php echo esc_html( $tospage->post_title );?></span>
			</h2>
			<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-fields' ) ); ?>">
			<div id="pmpro_license" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field', 'pmpro_license' ) ); ?>">
<?php 
	/**
	 * Hook to run formatting filters before displaying the content of your "Terms of Service" page at checkout.
	 *
	 * @since 2.4.1
	 * @since 2.10.1 We escape the content BEFORE the filter, so it can be overridden.
	 *
	 * @param string $pmpro_tos_content The content of the post assigned as the Terms of Service page.
	 * @param string $tospage The post assigned as the Terms of Service page.
	 *
	 * @return string $pmpro_tos_content
	 */
	$pmpro_tos_content = apply_filters( 'pmpro_tos_content', wp_kses_post( do_shortcode( $tospage->post_content ) ), $tospage );
	echo $pmpro_tos_content; //phpcs:ignore Content escaped above, but filtering allowed.
?>
				</div> <!-- end pmpro_license -->
				<?php
					if ( isset( $_REQUEST['tos'] ) ) {
						$tos = intval( $_REQUEST['tos'] );
					} else {
						$tos = "";
					}
				?>
				<label class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_label-inline pmpro_clickable', 'tos' ) ); ?>" for="tos">
		            <input type="checkbox" name="tos" value="1" id="tos" <?php checked( 1, $tos ); ?> />
		            <?php echo esc_html( sprintf( __( 'I agree to the %s', 'paid-memberships-pro' ), $tospage->post_title ) );?>
		        </label>
				<?php
				/**
				 * Allow adding text or more checkboxes after the Tos checkbox
                 * This is NOT intended to support multiple Tos checkboxes
				 *
				 * @since 2.8
				 */
				 do_action( "pmpro_checkout_after_tos" );
				 ?>
			</div> <!-- end pmpro_checkout-fields -->
		</div> <!-- end pmpro_tos_fields -->
		<?php
		}
	?>

	<?php do_action("pmpro_checkout_after_tos_fields"); ?>

	<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_checkout-field pmpro_captcha', 'pmpro_captcha' ) ); ?>">
	<?php
		$recaptcha = pmpro_getOption("recaptcha");
		if ( $recaptcha == 2 || $recaptcha == 1 ) {
			pmpro_recaptcha_get_html();
		}
	?>
	</div> <!-- end pmpro_captcha -->

	<?php
		 do_action('pmpro_checkout_after_captcha');
	?>

	<?php do_action("pmpro_checkout_before_submit_button"); ?>

	<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_submit' ) ); ?>">

		<?php if ( $pmpro_msg ) { ?>
			<div id="pmpro_message_bottom" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_message ' . $pmpro_msgt, $pmpro_msgt ) ); ?>"><?php echo wp_kses_post( apply_filters( 'pmpro_checkout_message', $pmpro_msg, $pmpro_msgt ) ); ?></div>
		<?php } else { ?>
			<div id="pmpro_message_bottom" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_message' ) ); ?>" style="display: none;"></div>
		<?php } ?>

		<?php if($pmpro_review) { ?>

			<span id="pmpro_submit_span">
				<input type="hidden" name="confirm" value="1" />
				<input type="hidden" name="token" value="<?php echo esc_attr($pmpro_paypal_token); ?>" />
				<input type="hidden" name="gateway" value="<?php echo esc_attr($gateway); ?>" />
				<input type="submit" id="pmpro_btn-submit" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_btn pmpro_btn-submit-checkout', 'pmpro_btn-submit-checkout' ) ); ?>" value="<?php esc_attr_e('Complete Payment', 'paid-memberships-pro' );?>" />
			</span>
			<img class="powered-by-stripe" src="<?php echo get_stylesheet_directory_uri() . '/images/powered-by-stripe.svg'; ?>" alt="powered by Stripe">
		<?php } else { ?>

			<?php
				$pmpro_checkout_default_submit_button = apply_filters('pmpro_checkout_default_submit_button', true);
				if($pmpro_checkout_default_submit_button)
				{
				?>
				<span id="pmpro_submit_span">
					<input type="hidden" name="submit-checkout" value="1" />
					<input type="submit"  id="pmpro_btn-submit" class="<?php echo esc_attr( pmpro_get_element_class(  'pmpro_btn pmpro_btn-submit-checkout', 'pmpro_btn-submit-checkout' ) ); ?>" value="<?php if($pmpro_requirebilling) { esc_html_e('Submit and Check Out', 'paid-memberships-pro' ); } else { esc_html_e('Submit and Confirm', 'paid-memberships-pro' );}?>" />
				</span>
			<img class="powered-by-stripe" src="<?php echo get_stylesheet_directory_uri() . '/images/powered-by-stripe.svg'; ?>" alt="powered by Stripe">

				<?php
				}
			?>

		<?php } ?>

		<span id="pmpro_processing_message" style="visibility: hidden;">
			<?php
				$processing_message = apply_filters("pmpro_processing_message", __("Processing...", 'paid-memberships-pro' ));
				echo wp_kses_post( $processing_message );
			?>
		</span>
	</div>
</form>
	
<div class="pmpro-checkoutnav">
<button id ='prev-tab' class="<?php echo esc_attr( pmpro_get_element_class(  'pmpro_btn' ) ); ?> nectar-button jumbo regular dg-yellow regular-button"><?php esc_html_e('Prev', 'paid-memberships-pro' ); ?></button>
<button id ='next-tab' class="<?php echo esc_attr( pmpro_get_element_class(  'pmpro_btn' ) ); ?> nectar-button jumbo regular dg-yellow regular-button"><?php esc_html_e('Next', 'paid-memberships-pro' ); ?></button>
</div>
<?php do_action('pmpro_checkout_after_form'); ?>

</div> <!-- end pmpro_level-ID -->
<script>
	jQuery(document).ready(function($){
		// Prevent manual editing of the date input field
		// $('body').on('keydown', '#bdob', function(e) {
		// 	e.preventDefault();
		// });
	});
</script>