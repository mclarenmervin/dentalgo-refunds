<?php
global $wpdb, $pmpro_msg, $pmpro_msgt, $current_user;

$pmpro_levels = pmpro_sort_levels_by_order( pmpro_getAllLevels(false, true) );
$pmpro_levels = apply_filters( 'pmpro_levels_array', $pmpro_levels );

if($pmpro_msg)
{
?>
<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_message ' . $pmpro_msgt, $pmpro_msgt ) ); ?>"><?php echo wp_kses_post( $pmpro_msg ); ?></div>
<?php
}
?>
<table id="pmpro_levels_table" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_table pmpro_checkout', 'pmpro_levels_table' ) ); ?>">
<thead>
  <tr>
    <th><?php esc_html_e('Plans', 'paid-memberships-pro' );?></th>
    <th><?php esc_html_e('Price', 'paid-memberships-pro' );?></th>
    <th>&nbsp;</th>
  </tr>
</thead>
<tbody>
    <?php    
    $count = 0;
    $has_any_level = false;
    $crnt_billing_amount = 0;
    if(is_user_logged_in() && function_exists('pmpro_hasMembershipLevel') && pmpro_hasMembershipLevel()) {
        global $current_user;
        $current_level = pmpro_getMembershipLevelForUser($current_user->ID);
        $crnt_billing_amount = $current_level->billing_amount;
    }

    foreach($pmpro_levels as $level) {
        $user_level = pmpro_getSpecificMembershipLevelForUser( $current_user->ID, $level->id );
        $has_level = ! empty( $user_level );
        $has_any_level = $has_level ?: $has_any_level;

        // Fetch the effective date from user meta
        $pmpro_effectivedate = get_user_meta($current_user->ID, 'pmpro_effectivedate', true);
        $effective_date = null;
        $interval = null;

        if (!empty($pmpro_effectivedate)) {
            // Try to parse the date in different formats
            try {
                $effective_date = DateTime::createFromFormat('mdY', $pmpro_effectivedate); // Format: 06012024
                if (!$effective_date) {
                    $effective_date = new DateTime($pmpro_effectivedate); // Fallback to a general date format
                }
                $today = new DateTime();
                $interval = $today->diff($effective_date)->days;
            } catch (Exception $e) {
                // Handle exception if date parsing fails
                $effective_date = null;
                $interval = null;
            }
        }

        // Determine the cancel URL
        // if ($effective_date && $interval !== null && $interval <= 33) {
        //     $cancel_url = get_permalink(1516);
        // } else {
        //     $cancel_url = site_url('account/membership-cancel/?levelstocancel='.$level->id);
        // }

        $cancel_url = site_url('account/membership-cancel/?levelstocancel='.$level->id);
    ?>
    <tr class="<?php if($count++ % 2 == 0) { ?>odd<?php } ?><?php if( $has_level ) { ?> active<?php } ?>">
        <th><?php echo $has_level ? "<strong>" . esc_html( $level->name ) . "</strong>" : esc_html( $level->name );?></th>
        <td>
            <?php
                $initial_price = floatval( $level->initial_payment ) - 20;
                echo "$".$initial_price." to be paid now.";
            ?>
        </td>
        <td>
            <?php
            if( intval($crnt_billing_amount) < intval($level->billing_amount)){
                $data = 'Upgrade';
            } else {
                $data = 'Downgrade';
            }
            $user_id = get_current_user_id();
            $downgraded = get_user_meta( $user_id, 'downgraded' );
            $disableatag = "";
            if($downgraded) {
                $data = "Downgrade In Process";
                $disableatag = " disabled";
            }
            ?>
        <?php if ( !$has_level ) { ?>                    
            <a aria-label="<?php esc_html_e( sprintf( __('Select the %s membership level', 'paid-memberships-pro' ), $level->name ) ); ?>" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_btn pmpro_btn-select', 'pmpro_btn-select' ) ); echo esc_attr( $disableatag ); ?>" href="<?php echo esc_url( pmpro_url( "checkout", "?level=" . $level->id, "https" ) ) ?>"><?php esc_html_e($data , 'paid-memberships-pro' ); ?></a>
        <?php } else { ?>      
            <?php
                if( pmpro_isLevelExpiringSoon( $user_level ) && $level->allow_signups ) {
                    ?>
                        <a aria-label="<?php esc_html_e( sprintf( __('Renew your %s membership level', 'paid-memberships-pro' ), $level->name ) ); ?>" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_btn pmpro_btn-select', 'pmpro_btn-select' ) ); ?>" href="<?php echo esc_url( pmpro_url( "checkout", "?level=" . $level->id, "https" ) ) ?>"><?php esc_html_e('Renew', 'paid-memberships-pro' );?></a>
                    <?php
                } else {
                    ?>
                        <a aria-label="<?php esc_html_e( sprintf( __('View your %s membership account', 'paid-memberships-pro' ), $level->name ) ); ?>" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_btn disabled', 'pmpro_btn' ) ); ?>" href="<?php echo esc_url( pmpro_url( "account" ) ) ?>"><?php esc_html_e('Your&nbsp;plan', 'paid-memberships-pro' );?></a>
                        <a aria-label="<?php esc_html_e( sprintf( __('View your %s membership account', 'paid-memberships-pro' ), $level->name ) ); ?>" class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_btn', 'pmpro_btn' ) ); ?>" href="<?php echo $cancel_url ?>"><?php esc_html_e('Cancel', 'paid-memberships-pro' );?></a>
                    <?php
                }
            ?>
        <?php } ?>
        </td>
    </tr>
    <?php
    }
    ?>
</tbody>
</table>
<p class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_actions_nav' ) ); ?>">
	<?php if( $has_any_level ) { ?>
		<a href="<?php echo esc_url( pmpro_url("account" ) ) ?>" id="pmpro_levels-return-account">&larr; <?php esc_html_e('Return to Your Account', 'paid-memberships-pro' );?></a>
	<?php } else { ?>
		<a href="<?php echo esc_url( home_url() ) ?>" id="pmpro_levels-return-home">&larr; <?php esc_html_e('Return to Home', 'paid-memberships-pro' );?></a>
	<?php } ?>
</p> <!-- end pmpro_actions_nav -->