<?php
// Shortcode Subscription Management
add_shortcode('pmpro_subscription_management', 'pmpro_subscription_management_shortcode');
function pmpro_subscription_management_shortcode() {
    ob_start();
    edit_profile_section();
    show_dependant_section();
    return ob_get_clean();
}

// AJAX callback functions
add_action('wp_ajax_add_dependent', 'add_dependent_callback');
add_action('wp_ajax_nopriv_add_dependent', 'add_dependent_callback');
function add_dependent_callback() {
    if (!isset($_POST['dependant'])) {
        wp_send_json_error('Dependent missing');
    }

    $user_id = get_current_user_id();
    $dependant = $_POST['dependant'];
    $current_dependents = get_user_meta($user_id, 'dependent_member', true);

    if (!$current_dependents) {
        $current_dependents = array();
    }

    if (isset($_POST['index']) && $_POST['index'] != '') {
        $index = intval($_POST['index']);
        if ($index < 0 || $index >= count($current_dependents)) {
            wp_send_json_error('Invalid index provided');
        }
        // Ensure the sqno is set even if it doesn't exist in the original data
        if (empty($current_dependents[$index]['sqno'])) {
            $current_dependents[$index]['sqno'] = str_pad($index + 1, 2, '0', STR_PAD_LEFT);
        }
        $dependant['sqno'] = $current_dependents[$index]['sqno'];
        $current_dependents[$index] = $dependant;
        update_user_meta($user_id, 'dependent_member', $current_dependents);
        wp_send_json_success('Dependent updated successfully!');
    } else {
        $no_dependant = count($current_dependents);
        if ($no_dependant >= 10) {
            wp_send_json_error('You cannot add more than 10 dependants');
        }
        $dependant['sqno'] = str_pad($no_dependant + 1, 2, '0', STR_PAD_LEFT); // Ensure unique sequence number
        array_push($current_dependents, $dependant);
        update_user_meta($user_id, 'dependent_member', $current_dependents);
        wp_send_json_success('Dependent added successfully!');
    }
}

add_action('wp_ajax_fetch_dependent_details', 'fetch_dependent_details_callback');
function fetch_dependent_details_callback() {
    if (!is_user_logged_in()) {
        wp_send_json_error('User is not logged in.');
    }

    $user_id = get_current_user_id();
    $dependent_index = isset($_POST['dependent_index']) ? intval($_POST['dependent_index']) : '';
    $current_dependents = get_user_meta($user_id, 'dependent_member', true);

    if (!$current_dependents || !isset($current_dependents[$dependent_index])) {
        wp_send_json_error('Dependent details not found.');
    }

    $dependent_details = $current_dependents[$dependent_index];

    $response = array(
        'status' => 'success',
        'data' => $dependent_details
    );

    wp_send_json($response);
}

add_action('wp_ajax_remove_dependent_user', 'remove_dependent_user_callback');
function remove_dependent_user_callback() {
    if (!isset($_POST['user_id']) || !isset($_POST['dependent_id'])) {
        wp_send_json_error('Missing parameters.');
    }
    $user_id = intval($_POST['user_id']);
    $key = intval($_POST['dependent_id']);
    $dependent_users = get_user_meta($user_id, 'dependent_member', true);
    if (isset($dependent_users[$key])) {
        unset($dependent_users[$key]);
        $dependent_users = array_values($dependent_users); // Reindex array
        // Reassign sequence numbers
        foreach ($dependent_users as $index => $dependent) {
            $dependent_users[$index]['sqno'] = str_pad($index + 1, 2, '0', STR_PAD_LEFT);
        }
        update_user_meta($user_id, 'dependent_member', $dependent_users);
    }

    wp_send_json_success('Dependent user removed successfully.');
}

add_action('wp_ajax_update_user', 'update_user');
add_action('wp_ajax_nopriv_update_user', 'update_user');
function update_user() {
    if (!isset($_POST['user_details'])) {
        wp_send_json_error('dependent missing');
    }
    $user_id = get_current_user_id();
    $user_details = $_POST['user_details'];
    update_user_meta($user_id, 'pmpro_baddress1', $user_details['address_line1']);
    update_user_meta($user_id, 'pmpro_baddress2', $user_details['address_line2']);
    update_user_meta($user_id, 'pmpro_bcity', $user_details['address_city']);
    update_user_meta($user_id, 'pmpro_bstate', $user_details['state']);
    update_user_meta($user_id, 'pmpro_bzipcode', $user_details['address_zip']);
    update_user_meta($user_id, 'pmpro_bphone', $user_details['phone']);
    update_user_meta($user_id, 'pmpro_bemail', $user_details['email']);
    update_user_meta($user_id, 'pmpro_bsqno', $user_details['sqno']);
    update_user_meta($user_id, 'pmpro_covrg', $user_details['covrg']);
    update_user_meta($user_id, 'pmpro_gc', $user_details['gc']);
    update_user_meta($user_id, 'pmpro_workphone', $user_details['workphone']);
    update_user_meta($user_id, 'pmpro_relation', $user_details['relation']);
    update_user_meta($user_id, 'pmpro_dob', $user_details['dob']);
    update_user_meta($user_id, 'pmpro_title', $user_details['title']);
    update_user_meta($user_id, 'pmpro_gender', $user_details['gender']);
    update_user_meta($user_id, 'pmpro_post', $user_details['post']);
    update_user_meta($user_id, 'pmpro_zip4', $user_details['address_zip4']);
    update_user_meta($user_id, 'middle_name', $user_details['mname']);

    $user_data = array(
        'ID' => $user_id,
        'first_name' => $user_details['fname'],
        'last_name' => $user_details['lname'],
        'user_email' => $user_details['email'],
    );

    $update_result = wp_update_user($user_data);
    wp_send_json($user_details['fname']);
}

add_action('wp_ajax_delete_plan', 'delete_plan');
add_action('wp_ajax_nopriv_delete_plan', 'delete_plan');
function delete_plan() {
    $user_id = get_current_user_id();
    $cancelled = pmpro_changeMembershipLevel(false, $user_id);

    if ($cancelled === true) {
        $user_email = get_userdata($user_id)->user_email;

        $user_subject = 'Membership Cancellation Confirmation';
        $user_message = 'Your membership has been cancelled.';

        wp_mail($user_email, $user_subject, $user_message);

        $admin_subject = 'Membership Cancellation Notification';
        $admin_message = 'User ID ' . $user_id . ' has cancelled their membership.';

        wp_mail(get_option('admin_email'), $admin_subject, $admin_message);
        wp_send_json_success();
    }
}


add_action('pmpro_after_change_membership_level', 'my_custom_function_after_membership_level_change', 10, 3);
function my_custom_function_after_membership_level_change($level_id, $user_id, $cancel_level) {
    if (!empty($cancel_level)) {
        if ($level_id == 2 || $level_id == 4) {
            delete_user_meta($user_id, 'dependent_member');
        }
    }
}

add_action('pmpro_after_change_membership_level', 'check_membership_downgrade', 10, 2);
function check_membership_downgrade($level_id, $user_id) {
    global $wpdb;
    $old_level = pmpro_getMembershipLevelForUser($user_id);
    $old_level_id = $wpdb->get_var("SELECT membership_id FROM $wpdb->pmpro_memberships_users WHERE user_id = '" . $user_id . "' ORDER BY id DESC");
    $level_ids = $wpdb->get_col("SELECT membership_id FROM $wpdb->pmpro_memberships_users WHERE user_id = '" . $user_id . "'");

    if (count($level_ids) >= 2) {
        $last_level_id = array_pop($level_ids);
        $second_last_level_id = end($level_ids);

        $last_level_price = get_membership_level_price($last_level_id);
        $second_last_level_price = get_membership_level_price($second_last_level_id);

        if ($last_level_price < $second_last_level_price) {
            $old_level_id = $second_last_level_id;
            pmpro_changeMembershipLevel($old_level_id, $user_id);
            update_user_meta($user_id, 'downgraded', $level_id);
        } else {
            $downgraded = get_user_meta($user_id, 'downgraded');
            if (isset($downgraded)) {
                delete_user_meta($user_id, 'downgraded');
            }
        }
    }
}

function get_membership_level_price($level_id) {
    $level = pmpro_getLevel($level_id);
    if (!empty($level) && isset($level->initial_payment)) {
        return $level->initial_payment;
    } else {
        return false;
    }
}

/* Grace time fore expired memberships (bypassed)
add_action('pmpro_membership_post_membership_expiry', 'my_pmpro_membership_post_membership_expiry_dg', 10, 2);
function my_pmpro_membership_post_membership_expiry_dg($user_id, $level_id) {
    $grace_level = get_user_meta($user_id, 'grace_level', true);
    if (empty($grace_level) || $grace_level !== $level_id) {
        $grace_level = array();
        $grace_level['user_id'] = $user_id;
        $grace_level['membership_id'] = $level_id;
        $grace_level['enddate'] = date('Y-m-d H:i:s', strtotime('+7 days', current_time('timestamp')));
        $changed = pmpro_changeMembershipLevel($grace_level, $user_id);
        update_user_meta($user_id, 'grace_level', $level_id);
    } else {
        delete_user_meta($user_id, 'grace_level');
    }
} */



// Show Dependent section for family annual + monthly plans
function show_dependant_section() {
    if (is_user_logged_in() && pmpro_hasMembershipLevel()) {
        $current_level = pmpro_getMembershipLevelForUser(get_current_user_id());
        $plan_id = $current_level->ID;
        if ($plan_id == 2 || $plan_id == 4) {
            ?>
            <hr>
            <div class="dependent-section">
                <h4 class="add-top member-details">Manage Dependents</h4>
                <?php
                $user_id = get_current_user_id();
                $dependent_users = get_user_meta($user_id, 'dependent_member', true);
                if (!empty($dependent_users)) {
                    ?>
                    <ul class="add-dependent">
                        <?php 
                        $seq_no = 1; // Start sequence number for dependents at 1
                        foreach ($dependent_users as $index => $dependent_user): ?>
                            <?php
                            $name = $dependent_user['fname'] . ' ' . $dependent_user['lname'];
                            $relation = $dependent_user['relation'];
                            if ($relation === "C") {
                                $relation = "Child";
                            } else if ($relation === "S") {
                                $relation = "Spouse";
                            } else if ($relation === "O") {
                                $relation = "Other";
                            }
                            ?>
                            <li>
                                <div class="dependent-summary dependent">
                                    <span>Dependent: </span><?php echo $name; ?>
                                </div>
                                <div class="dependent-summary relation">
                                    <span> Relation: </span><?php echo $relation; ?>
                                </div>
                                <div class="action-buttons">
                                    <button class="remove-dependent" data-dependent-user-id="<?php echo $index; ?>">Remove</button>
                                    <button class="edit-dependent" data-dependent-user-id="<?php echo $index; ?>">Edit</button>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php
                }
                ?>

                <div id="dependant-form" class="dependent-wrapper">
                    <div class="profile-formfield-wrapper">
                        <div class="profile-formfield section-header notop width-12">Dependent Details</div>
                        <div class="profile-formfield title width-3">
                            <div class="form-floating">
                                <input type="text" name="dependant_title" id="dependant_title" class="form-control" maxlength="3"
                                    placeholder="Title" />
                                <label for="dependant_title"><?php esc_html_e('Title', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <div class="profile-formfield firstname width-3">
                            <div class="form-floating">
                                <input type="text" name="dependant_fname" id="dependant_fname" class="form-control" maxlength="15"
                                    placeholder="First Name" />
                                <label for="dependant_fname"><?php esc_html_e('First Name', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <div class="profile-formfield middlename width-3">
                            <div class="form-floating">
                                <input type="text" name="dependant_mname" id="dependant_mname" class="form-control" maxlength="1"
                                    placeholder="Middle Initial" />
                                <label for="dependant_mname"><?php esc_html_e('Middle Initial', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <div class="profile-formfield lastname width-3">
                            <div class="form-floating">
                                <input type="text" name="dependant_lname" id="dependant_lname" class="form-control" maxlength="20"
                                    placeholder="Last Name" />
                                <label for="dependant_lname"><?php esc_html_e('Last Name', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <div class="profile-formfield relation width-4">
                            <div class="form-floating">
                                <select name="dependant_relation" id="dependant_relation" class="form-select">
                                    <option value="C"><?php esc_html_e('Child', 'paid-memberships-pro'); ?></option>
                                    <option value="S"><?php esc_html_e('Spouse', 'paid-memberships-pro'); ?></option>
                                    <option value="O"><?php esc_html_e('Other', 'paid-memberships-pro'); ?></option>
                                </select>
                                <label for="dependant_relation"><?php esc_html_e('Relation', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <div class="profile-formfield dob width-4">
                            <div class="form-floating">
                                <input id="dependant_dob" name="dependant_dob" max="MM-dd-yyyy" type="text"
                                    class="form-control" size="30" />
                                <label for="dependant_dob"><?php esc_html_e(' DOB', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <div class="profile-formfield gender width-4">
                            <div class="form-floating">
                                <select name="dependant_gender" id="dependant_gender" class="form-select">
                                    <option value="M"><?php esc_html_e('Male', 'paid-memberships-pro'); ?></option>
                                    <option value="F"><?php esc_html_e('Female', 'paid-memberships-pro'); ?></option>
                                </select>
                                <label for="dependant_gender"><?php esc_html_e('Gender', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <div class="profile-formfield section-header width-12">Dependent Address</div>
                        <div class="profile-formfield address1 width-6">
                            <div class="form-floating">
                                <input type="text" name="dependant_addrs1" id="dependant_addrs1" class="form-control" maxlength="33"
                                    placeholder="Address Line 1" />
                                <label for="dependant_addrs1"><?php esc_html_e('Address Line 1', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <div class="profile-formfield address2 width-6">
                            <div class="form-floating">
                                <input type="text" name="dependant_addrs2" id="dependant_addrs2" class="form-control" maxlength="33"
                                    placeholder="Address Line 2" />
                                <label for="dependant_addrs2"><?php esc_html_e('Address Line 2', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <div class="profile-formfield city width-4">
                            <div class="form-floating">
                                <input type="text" name="dependant_city" id="dependant_city" class="form-control" maxlength="21"
                                    placeholder="City">
                                <label for="dependant_city"><?php esc_html_e('City', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                       <div class="profile-formfield state width-4">
							<div class="form-floating">
								<select id="dependant_state" class="form-select" name="dependant_state">
									<?php
									// Array of all US states with abbreviations
									$us_states = array(
										"AL" => "Alabama", "AK" => "Alaska", "AZ" => "Arizona", "AR" => "Arkansas", "CA" => "California",
										"CO" => "Colorado", "CT" => "Connecticut", "DE" => "Delaware", "FL" => "Florida", "GA" => "Georgia",
										"HI" => "Hawaii", "ID" => "Idaho", "IL" => "Illinois", "IN" => "Indiana", "IA" => "Iowa",
										"KS" => "Kansas", "KY" => "Kentucky", "LA" => "Louisiana", "ME" => "Maine", "MD" => "Maryland",
										"MA" => "Massachusetts", "MI" => "Michigan", "MN" => "Minnesota", "MS" => "Mississippi", "MO" => "Missouri",
										"MT" => "Montana", "NE" => "Nebraska", "NV" => "Nevada", "NH" => "New Hampshire", "NJ" => "New Jersey",
										"NM" => "New Mexico", "NY" => "New York", "NC" => "North Carolina", "ND" => "North Dakota", "OH" => "Ohio",
										"OK" => "Oklahoma", "OR" => "Oregon", "PA" => "Pennsylvania", "RI" => "Rhode Island", "SC" => "South Carolina",
										"SD" => "South Dakota", "TN" => "Tennessee", "TX" => "Texas", "UT" => "Utah", "VT" => "Vermont",
										"VA" => "Virginia", "WA" => "Washington", "WV" => "West Virginia", "WI" => "Wisconsin", "WY" => "Wyoming"
									);

									// States to exclude
									$exclude_states = array("VT", "UT", "WA");

									// Loop through each state and add to dropdown if not in exclude list
									foreach ($us_states as $abbr => $state) {
										if (!in_array($abbr, $exclude_states)) {
											echo "<option value=\"$abbr\">$state</option>";
										}
									}
									?>
								</select>
								<label for="dependant_state"><?php esc_html_e('State', 'paid-memberships-pro'); ?></label>
							</div>
						</div>
                        <div class="profile-formfield zip width-4">
                            <div class="form-floating">
                                <input type="text" name="dependant_zip" id="dependant_zip" class="form-control" maxlength="5"
                                    placeholder="Zip">
                                <label for="dependant_zip"><?php esc_html_e('Zip', 'paid-memberships-pro'); ?></label>
                            </div>
                        </div>
                        <input type="hidden" name="dependant_uid" id="dependant_uid"
                            value="<?php echo esc_attr(get_current_user_id()); ?>">
                        <input type="hidden" name="dependant_sqno" id="dependant_sqno">
                        <input type="hidden" name="dependant_covrg" id="dependant_covrg" value="MD">
                        <input type="hidden" name="dependant_gc" id="dependant_gc" value="">
                        <input type="hidden" name="dependant_index" id="dependant_index">

                        <div class="profile-formfield submit width-12">
                            <input type="submit" id='add-dependant-btn' value="Add Dependent">
                            <div id="spinner" style="display: none;">Adding...</div>
                            <div id="message" style="display: none;"></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }
    }
}

// Profile Edit Section 
function edit_profile_section() {
    $user_id = get_current_user_id();
    $user_data = get_userdata($user_id);
    $username = $user_data->user_login;
    $uniqueid = $user_id;
    $user_email = $user_data->user_email;
    $first_name = $user_data->first_name;
    $last_name = $user_data->last_name;
    $mname = get_user_meta($user_id, 'middle_name', true);
    $phone = get_user_meta($user_id, 'pmpro_bphone', true);
    $addrs1 = get_user_meta($user_id, 'pmpro_baddress1', true);
    $addrs2 = get_user_meta($user_id, 'pmpro_baddress2', true);
    $city = get_user_meta($user_id, 'pmpro_bcity', true);
    $zip = get_user_meta($user_id, 'pmpro_bzipcode', true);
    $zip4 = get_user_meta($user_id, 'pmpro_zip4', true);
    $dob = get_user_meta($user_id, 'pmpro_dob', true);
    $title = get_user_meta($user_id, 'pmpro_title', true);
    $state = get_user_meta($user_id, 'pmpro_bstate', true);
    $start_dt = get_user_meta($user_id, 'pmpro_bplanstart', true);
    $effective_dt = get_user_meta($user_id, 'pmpro_effectivedate', true);
    $gender = get_user_meta($user_id, 'pmpro_gender', true);
    $post = get_user_meta($user_id, 'pmpro_post', true);
    $relation = get_user_meta($user_id, 'pmpro_relation', true);
    $workphone = get_user_meta($user_id, 'pmpro_workphone', true);

    $strt_msg = '';
    if (isset($start_dt) && !empty($start_dt)) {
        $strt_msg = '<strong>Registration Date:</strong> ' . $start_dt . '</br></br>';
    }

    $gc = get_user_meta($user_id, 'pmpro_gc', true);
    $gc_msg = '<strong>Account status:</strong> Pending processing';
    if (isset($gc) && !empty($gc)) {
        $gc_msg = 'Account status: Your plan is active';
        echo $gc_msg;
    }

	// Use level ID to determine coverage level. 2 + 4 are family plans, 1+3 single plans;
    $current_level = pmpro_getMembershipLevelForUser(get_current_user_id());
    $plan_id = $current_level->ID;
    $user_blank = 'blank';
    $user_covrg = 'MO';
    if ($plan_id == 2 || $plan_id == 4) {
        $user_covrg = 'MF';
    }
    
    $current_user_id = get_current_user_id();
    $current_level = pmpro_getMembershipLevelForUser($current_user_id);
    $end_msg = '';

    $pmpro_member_action_links = '<a id="pmpro_actionlink-change" href="' . esc_url(pmpro_url('levels')) . '" aria-label="' . esc_html__(sprintf(esc_html__('Change %1$s Membership', 'paid-memberships-pro'), $current_level->ID)) . '">' . esc_html__('Change your plan', 'paid-memberships-pro') . '</a>';
    ?>
    <span id='start-date-section'><?php echo $strt_msg; ?></span><br>
<?php if (isset($gc) && !empty($gc)) : ?>
    <span id='account-status-section'><?php echo $gc_msg; ?></span><br><br>
<?php endif; ?>    

    <div class="account-actions">
        <div class="profile-formfield submit width-12">
            <input type="submit" id='update-profile-btn' value="Update profile">
            <?php
            $reset_password_url = wp_lostpassword_url();
            echo '<a href="' . esc_url($reset_password_url) . '"><br>Want to change your password?</a><br><br> ';
            ?>
        </div>
    </div>

    <h4 class="member-details">Account Holder</h4>

    <div class="profile-wrapper">
        <div class="profile-formfield-wrapper">
            <div class="profile-formfield section-header notop width-12">Personal Details</div>
            <div class="profile-formfield title width-1">
                <div class="form-floating">
                    <input type="text" name="title" id="title" class="form-control" value="<?php echo esc_attr($title); ?>" maxlength="3" placeholder="Title" />
                    <label for="title"><?php esc_html_e('Title', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield firstname width-3">
                <div class="form-floating">
                    <input type="text" name="first_name" id="first_name" class="form-control" value="<?php echo esc_attr($first_name); ?>" maxlength="15" placeholder="First Name">
                    <label for="first_name"><?php esc_html_e('First Name', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield middlename width-3">
                <div class="form-floating">
                    <input type="text" name="middle_name" id="middle_name" class="form-control" value="<?php echo esc_attr($mname); ?>" maxlength="1" placeholder="Middle Name">
                    <label for="middle_name"><?php esc_html_e('Middle Initial', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield lastname width-4">
                <div class="form-floating">
                    <input type="text" name="last_name" id="last_name" class="form-control" value="<?php echo esc_attr($last_name); ?>" maxlength="20" placeholder="Last Name">
                    <label for="last_name"><?php esc_html_e('Last Name', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield postname width-1">
                <div class="form-floating">
                    <input type="text" name="user_postname" id="user_postname" class="form-control" value="<?php echo esc_attr($post); ?>" maxlength="4" placeholder="Suffix">
                    <label for="user_postname"><?php esc_html_e('Suffix', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield email width-6">
                <div class="form-floating">
                    <input type="text" name="user_email" id="user_email" class="form-control" value="<?php echo esc_attr($user_email); ?>" maxlength="64" placeholder="E-mail">
                    <label for="user_email"><?php esc_html_e('Email', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield phone width-6">
                <div class="form-floating">
                    <input type="number" name="user_phone" id="user_phone" class="form-control" value="<?php echo esc_attr($phone); ?>" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" maxlength="10" placeholder="Phone" onKeyPress="if(this.value.length==10) return false;">
                    <label for="user_phone"><?php esc_html_e('Phone', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield gender width-6">
                <div class="form-floating">
                    <select name="user_gender" id="user_gender" class="form-select" aria-label="Select your gender">
                        <option value="M" <?php selected($gender, 'M'); ?>>
                            <?php esc_html_e('Male', 'paid-memberships-pro'); ?></option>
                        <option value="F" <?php selected($gender, 'F'); ?>>
                            <?php esc_html_e('Female', 'paid-memberships-pro'); ?></option>
                    </select>
                    <label for="user_gender"><?php esc_html_e('Gender', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield dob width-6">
                <div class="form-floating">
                    <input id="user_dob" class="form-control" name="user_dob" max="MM-dd-yyyy" type="text" value="<?php echo esc_attr($dob); ?>" />
                    <label for="user_dob"><?php esc_html_e('DOB', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield section-header width-12">Address Details</div>
            <div class="profile-formfield address1 width-6">
                <div class="form-floating">
                    <input type="text" name="address_line1" id="address_line1" class="form-control" value="<?php echo esc_attr($addrs1); ?>" maxlength="33" placeholder="Address Line 1" />
                    <label for="address_line1"><?php esc_html_e('Address Line 1', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield address2 width-6">
                <div class="form-floating">
                    <input type="text" name="address_line2" id="address_line2" class="form-control" value="<?php echo esc_attr($addrs2); ?>" maxlength="33" placeholder="Address Line 2" />
                    <label for="address_line2"><?php esc_html_e('Address Line 2', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield city width-4">
                <div class="form-floating">
                    <input type="text" name="address_city" id="address_city" class="form-control" value="<?php echo esc_attr($city); ?>" maxlength="21" placeholder="City" />
                    <label for="address_city"><?php esc_html_e('City', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
			
			<div class="profile-formfield state width-4">
				<div class="form-floating">
					<select id="state" class="form-select" name="state">
						<?php
						// Array of all US states with abbreviations
						$us_states = array(
							"AL" => "Alabama", "AK" => "Alaska", "AZ" => "Arizona", "AR" => "Arkansas", "CA" => "California",
							"CO" => "Colorado", "CT" => "Connecticut", "DE" => "Delaware", "FL" => "Florida", "GA" => "Georgia",
							"HI" => "Hawaii", "ID" => "Idaho", "IL" => "Illinois", "IN" => "Indiana", "IA" => "Iowa",
							"KS" => "Kansas", "KY" => "Kentucky", "LA" => "Louisiana", "ME" => "Maine", "MD" => "Maryland",
							"MA" => "Massachusetts", "MI" => "Michigan", "MN" => "Minnesota", "MS" => "Mississippi", "MO" => "Missouri",
							"MT" => "Montana", "NE" => "Nebraska", "NV" => "Nevada", "NH" => "New Hampshire", "NJ" => "New Jersey",
							"NM" => "New Mexico", "NY" => "New York", "NC" => "North Carolina", "ND" => "North Dakota", "OH" => "Ohio",
							"OK" => "Oklahoma", "OR" => "Oregon", "PA" => "Pennsylvania", "RI" => "Rhode Island", "SC" => "South Carolina",
							"SD" => "South Dakota", "TN" => "Tennessee", "TX" => "Texas", "UT" => "Utah", "VT" => "Vermont",
							"VA" => "Virginia", "WA" => "Washington", "WV" => "West Virginia", "WI" => "Wisconsin", "WY" => "Wyoming"
						);

						// States to exclude
						$exclude_states = array("VT", "UT", "WA");

						// Loop through each state and add to dropdown if not in exclude list
						foreach ($us_states as $abbr => $state_name) {
							if (!in_array($abbr, $exclude_states)) {
								$selected = ($state === $abbr) ? 'selected' : '';
								echo "<option value=\"$abbr\" $selected>$state_name</option>";
							}
						}
						?>
					</select>
					<label for="state"><?php esc_html_e('State', 'paid-memberships-pro'); ?></label>
				</div>
			</div>
			
            <div class="profile-formfield zip width-4">
                <div class="form-floating">
                    <input type="text" name="address_zip" id="address_zip" class="form-control" value="<?php echo esc_attr($zip); ?>" maxlength="5" placeholder="Zip Code" />
                    <label for="address_zip"><?php esc_html_e('Zip', 'paid-memberships-pro'); ?></label>
                </div>
            </div>
            <div class="profile-formfield zip-4 width-12">
                <label for="address_zip4"><?php esc_html_e('Plus 4', 'paid-memberships-pro'); ?></label>
                <input type="text" name="address_zip4" id="address_zip4" value="<?php echo esc_attr($zip4); ?>" maxlength="4">
            </div>
            <div class="dg-spacer-2"></div>
            <input type="hidden" name="user_uid" id="user_uid" value="<?php echo esc_attr(get_current_user_id()); ?>">
            <input type="hidden" name="user_sqno" id="user_sqno" value="00">
            <input type="hidden" name="user_covrg" id="user_covrg" value="<?php echo esc_attr($user_covrg); ?>">
            <input type="hidden" name="user_gc" id="user_gc" value="">
            <input type="hidden" name="user_relation" id="user_relation" value="">
        </div>
    </div>
    <?php
}


// Confirmation message tweak
remove_filter('pmpro_confirmation_message', 'pmpro_pmpro_confirmation_message');
add_filter('pmpro_confirmation_message', 'my_pmpro_confirmation_message', 20, 1);
function my_pmpro_confirmation_message($message) {
    global $current_user;
    $message = '';
    $message .= '<p>Thank you for choosing the <strong>' . pmpro_getMembershipLevelForUser($current_user->ID)->name . '</strong> membership.</p>';
    if (function_exists('pmproec_isEmailConfirmationLevel') && 0 != intval(pmpro_getMembershipLevelForUser($current_user->ID)) && pmproec_isEmailConfirmationLevel(intval(pmpro_getMembershipLevelForUser($current_user->ID)->ID))) {
        if ($current_user->pmpro_email_confirmation_key != 'validated') {
            $message .= '<p>We sent an email to <strong>' . $current_user->user_email . '</strong>. Please check your inbox and confirm your email. Once it’s done you will be able to activate your <strong>' . pmpro_getMembershipLevelForUser($current_user->ID)->name . '</strong> membership.</p>';
        }
    }
    return $message;
}