<?php 

// Time of Day Shortcode
add_shortcode('time_of_day', 'time_of_day_shortcode');
function time_of_day_shortcode() {
    $current_hour = date('G');
    $morning_start = 6; // 6:00 AM
    $afternoon_start = 12; // 12:00 PM
    $evening_start = 18; // 6:00 PM
    if ($current_hour >= $morning_start && $current_hour < $afternoon_start) {
        $time_of_day = 'Good morning';
    } elseif ($current_hour >= $afternoon_start && $current_hour < $evening_start) {
        $time_of_day = 'Good afternoon';
    } else {
        $time_of_day = 'Good evening';
    }
    return $time_of_day;
}


// Shortcode to show plan
function custom_pmpro_membership_message() {
    if (function_exists('pmpro_getMembershipLevelForUser')) {
        $user_id = get_current_user_id();
        $membership_level = pmpro_getMembershipLevelForUser($user_id);

        if ($membership_level) {
            return 'You are currently on the <strong>' . $membership_level->name . '</strong> plan.';
        } else {
            return 'You do not have an active DentalGo plan. Please <a href="https://dentalgo.com/account/plans/"><strong>select a plan</strong></a> to continue receiving your benefits.';
        }
    } else {
        return 'PMPro is not installed or activated.';
    }
}
function register_custom_pmpro_shortcode() {
    add_shortcode('show_pmproplan', 'custom_pmpro_membership_message');
}
add_action('init', 'register_custom_pmpro_shortcode');




// Shortcode to show dashboard message
function custom_pmpro_dashboard_message() {
    if (function_exists('pmpro_getMembershipLevelForUser')) {
        $user_id = get_current_user_id();
        $membership_level = pmpro_getMembershipLevelForUser($user_id);

        if ($membership_level) {
            $billing_amount = do_shortcode('[pmpro_member field="membership_billing_amount"]');
            $next_payment_date = do_shortcode('[pmpro_member field="next_payment_date"]');
            return 'Your next payment of ' . $billing_amount . ' will be made on ' . $next_payment_date . '.';
        } else {
            return 'Your DentalGo plan has expired. Please <a href="https://dentalgo.com/account/plans/"><strong>select a plan</strong></a> to continue receiving your benefits.';
        }
    } else {
        return 'PMPro is not installed or activated.';
    }
}
function register_custom_pmpro_dashboard_shortcode() {
    add_shortcode('show_pmprodashboard', 'custom_pmpro_dashboard_message');
}
add_action('init', 'register_custom_pmpro_dashboard_shortcode');
