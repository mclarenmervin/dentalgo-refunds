<?php

// Adds Fields To User Edit section
add_action('show_user_profile', 'add_custom_user_fields');
add_action('edit_user_profile', 'add_custom_user_fields');
add_action('personal_options_update', 'save_custom_user_fields');
add_action('edit_user_profile_update', 'save_custom_user_fields');

function add_custom_user_fields($user) {
    ?>
    <table class="form-table">
        <tr>
            <th><label for="custom_field"><?php _e('Group Code', 'paid-memberships-pro'); ?></label></th>
            <td>
                <input type="text" name="pmpro_gc" id="pmpro_gc"
                    value="<?php echo esc_attr(get_the_author_meta('pmpro_gc', $user->ID)); ?>"
                    class="regular-text" /><br />
                <span class="description"><?php _e('Enter Group code here.', 'paid-memberships-pro'); ?></span>
            </td>
        </tr>
    </table>
    <?php
}

function save_custom_user_fields($user_id) {
    if (current_user_can('edit_user', $user_id)) {
        update_user_meta($user_id, 'pmpro_gc', $_POST['pmpro_gc']);
    }
}



add_action('show_user_profile', 'extra_profile_fields');
add_action('edit_user_profile', 'extra_profile_fields');
add_action('personal_options_update', 'extra_save_profile_fields');
add_action('edit_user_profile_update', 'extra_save_profile_fields');

function extra_profile_fields($user) { 
    $userid = $user->id;
    $current_level = pmpro_getMembershipLevelForUser($user->ID);
    $phone = get_user_meta($userid, 'pmpro_bphone', true);
    $addrs1 = get_user_meta($userid, 'pmpro_baddress1', true);
    $addrs2 = get_user_meta($userid, 'pmpro_baddress2', true);
    $city = get_user_meta($userid, 'pmpro_bcity', true);
    $zip = get_user_meta($userid, 'pmpro_bzipcode', true);
    $zip4 = get_user_meta($userid, 'pmpro_zip4', true);
    $dob = get_user_meta($userid, 'pmpro_dob', true);
    $title = get_user_meta($userid, 'pmpro_title', true);
    $state = get_user_meta($userid, 'pmpro_bstate', true);
    $start_dt = get_user_meta($userid, 'pmpro_bplanstart', true);
    $effective_dt = get_user_meta($userid, 'pmpro_effectivedate', true);
    $gender = get_user_meta($userid, 'pmpro_gender', true);
    if ($gender == 'M') {
        $gender = 'Male';
    } else if ($gender == 'F') {
        $gender = 'Female';
    }
    $post = get_user_meta($userid, 'pmpro_post', true);
    ?>
    <h3><?php _e('Extra User Details'); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="userid">User ID</label></th>
            <td>
            <input type="text" name="userid" id="userid" value="<?php echo $userid; ?>" class="regular-text" disabled />
            </td>
        </tr>

        <tr>
            <th><label for="current_level">Current Level</label></th>
            <td>
            <input type="text" name="current_level" id="current_level" value="<?php echo $current_level->name; ?>" class="regular-text" disabled />
            </td>
        </tr>

        <tr>
            <th><label for="plan_start">Plan Start (Sign-Up) Date</label></th>
            <td>
            <input type="text" name="plan_start" id="plan_start" value="<?php echo $start_dt; ?>" class="regular-text" disabled />
            </td>
        </tr>
        
        <tr>
            <th><label for="effective_date">Effective Date</label></th>
            <td>
            <input type="text" name="effective_date" id="effective_date" placeholder="Effective Date (MMDDYYYY, only use 01 for DD)" value="<?php echo $effective_dt; ?>" class="regular-text" />
            </td>
        </tr>

        <tr>
            <th><label for="userdob">Date Of Birth</label></th>
            <td>
            <input type="text" name="userdob" id="userdob" value="<?php echo $dob; ?>" class="regular-text" disabled />
            </td>
        </tr>

        <tr>
            <th><label for="gender">Gender</label></th>
            <td>
            <input type="text" name="gender" id="gender" value="<?php echo $gender; ?>" class="regular-text" disabled />
            </td>
        </tr>

        <tr>
            <th><label for="userphone">Phone</label></th>
            <td>
            <input type="text" name="userphone" id="userphone" value="<?php echo $phone; ?>" class="regular-text" />
            </td>
        </tr>

        <tr>
            <th><label for="addresslineone">Address Line 1</label></th>
            <td>
            <input type="text" name="addresslineone" id="addresslineone" value="<?php echo $addrs1; ?>" class="regular-text" />
            </td>
        </tr>

        <tr>
            <th><label for="addresslinetwo">Address Line 2</label></th>
            <td>
            <input type="text" name="addresslinetwo" id="addresslinetwo" value="<?php echo $addrs2; ?>" class="regular-text" />
            </td>
        </tr>

        <tr>
            <th><label for="city">City</label></th>
            <td>
            <input type="text" name="city" id="city" value="<?php echo $city; ?>" class="regular-text" />
            </td>
        </tr>

		<tr>
			<th><label for="state">State</label></th>
			<td>
				<select id="state" class="form-select" name="state">
					<?php
					// Array of all US states with abbreviations
					$us_states = array(
						"AL" => "Alabama", "AK" => "Alaska", "AZ" => "Arizona", "AR" => "Arkansas", "CA" => "California",
						"CO" => "Colorado", "CT" => "Connecticut", "DE" => "Delaware", "FL" => "Florida", "GA" => "Georgia",
						"HI" => "Hawaii", "ID" => "Idaho", "IL" => "Illinois", "IN" => "Indiana", "IA" => "Iowa",
						"KS" => "Kansas", "KY" => "Kentucky", "LA" => "Louisiana", "ME" => "Maine", "MD" => "Maryland",
						"MA" => "Massachusetts", "MI" => "Michigan", "MN" => "Minnesota", "MS" => "Mississippi", "MO" => "Missouri",
						"MT" => "Montana", "NE" => "Nebraska", "NV" => "Nevada", "NH" => "New Hampshire", "NJ" => "New Jersey",
						"NM" => "New Mexico", "NY" => "New York", "NC" => "North Carolina", "ND" => "North Dakota", "OH" => "Ohio",
						"OK" => "Oklahoma", "OR" => "Oregon", "PA" => "Pennsylvania", "RI" => "Rhode Island", "SC" => "South Carolina",
						"SD" => "South Dakota", "TN" => "Tennessee", "TX" => "Texas", "UT" => "Utah", "VT" => "Vermont",
						"VA" => "Virginia", "WA" => "Washington", "WV" => "West Virginia", "WI" => "Wisconsin", "WY" => "Wyoming"
					);

					// States to exclude
					$exclude_states = array("VT", "UT", "WA");

					// Loop through each state and add to dropdown if not in exclude list
					foreach ($us_states as $abbr => $state_name) {
						if (!in_array($abbr, $exclude_states)) {
							$selected = ($state === $abbr) ? 'selected' : '';
							echo "<option value=\"$abbr\" $selected>$state_name</option>";
						}
					}
					?>
				</select>
			</td>
		</tr>
		
        <tr>
            <th><label for="zip">Zip Code</label></th>
            <td>
            <input type="text" name="zip" id="zip" value="<?php echo $zip; ?>" class="regular-text" />
            </td>
        </tr>
    </table>
    <?php
}

function extra_save_profile_fields($user_id) {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'update-user_' . $user_id)) {
        return;
    }
    if (!current_user_can('edit_user', $user_id)) {
        return;
    }
    update_user_meta($user_id, 'pmpro_effectivedate', sanitize_text_field($_POST['effective_date']));
    update_user_meta($user_id, 'pmpro_baddress1', sanitize_text_field($_POST['addresslineone']));
    update_user_meta($user_id, 'pmpro_baddress2', sanitize_text_field($_POST['addresslinetwo']));
    update_user_meta($user_id, 'pmpro_bphone', sanitize_text_field($_POST['userphone']));
    update_user_meta($user_id, 'pmpro_bcity', sanitize_text_field($_POST['city']));
    update_user_meta($user_id, 'pmpro_bstate', sanitize_text_field($_POST['state']));
    update_user_meta($user_id, 'pmpro_bzipcode', sanitize_text_field($_POST['zip']));
}




// Debugging function to log the email templates being processed




// Maintenance Tasks
add_action('admin_menu', 'dentalgo_maintenance_menu');
function dentalgo_maintenance_menu() {
    add_menu_page(
        'DentalGo Maintenance', // Page title
        'DentalGo Maintenance', // Menu title
        'manage_options',       // Capability
        'dentalgo-maintenance', // Menu slug
        'dentalgo_maintenance_page' // Callback function
    );
}

function dentalgo_maintenance_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    if (isset($_POST['fix_dependent_sequence'])) {
        fix_dependent_sequence(); // Call the function to fix the sequences
        echo '<div class="notice notice-success is-dismissible"><p>Dependent sequences fixed successfully.</p></div>';
    }
    if (isset($_POST['update_state_abbreviations'])) {
        update_state_abbreviations(); // Call the function to update state abbreviations
        echo '<div class="notice notice-success is-dismissible"><p>State abbreviations updated successfully.</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>DentalGo Maintenance</h1>
        <form method="post">
            <input type="hidden" name="fix_dependent_sequence" value="1">
            <?php submit_button('Fix Dependent Sequences'); ?>
        </form>
        <form method="post">
            <input type="hidden" name="update_state_abbreviations" value="1">
            <?php submit_button('Update State Abbreviations'); ?>
        </form>
    </div>
    <?php
}

function fix_dependent_sequence() {
    $users = get_users();
    foreach ($users as $user) {
        $user_id = $user->ID;
        $dependents = get_user_meta($user_id, 'dependent_member', true);

        if ($dependents && is_array($dependents)) {
            $dependents = array_values($dependents);

            foreach ($dependents as $index => &$dependent) {
                $dependent['sqno'] = str_pad($index + 1, 2, '0', STR_PAD_LEFT);
            }

            update_user_meta($user_id, 'dependent_member', $dependents);
        }
    }
}

function update_state_abbreviations() {
    // Array mapping full state names to abbreviations
    $state_abbreviations = array(
        "Alabama" => "AL", "Alaska" => "AK", "Arizona" => "AZ", "Arkansas" => "AR", "California" => "CA",
        "Colorado" => "CO", "Connecticut" => "CT", "Delaware" => "DE", "Florida" => "FL", "Georgia" => "GA",
        "Hawaii" => "HI", "Idaho" => "ID", "Illinois" => "IL", "Indiana" => "IN", "Iowa" => "IA",
        "Kansas" => "KS", "Kentucky" => "KY", "Louisiana" => "LA", "Maine" => "ME", "Maryland" => "MD",
        "Massachusetts" => "MA", "Michigan" => "MI", "Minnesota" => "MN", "Mississippi" => "MS", "Missouri" => "MO",
        "Montana" => "MT", "Nebraska" => "NE", "Nevada" => "NV", "New Hampshire" => "NH", "New Jersey" => "NJ",
        "New Mexico" => "NM", "New York" => "NY", "North Carolina" => "NC", "North Dakota" => "ND", "Ohio" => "OH",
        "Oklahoma" => "OK", "Oregon" => "OR", "Pennsylvania" => "PA", "Rhode Island" => "RI", "South Carolina" => "SC",
        "South Dakota" => "SD", "Tennessee" => "TN", "Texas" => "TX", "Utah" => "UT", "Vermont" => "VT",
        "Virginia" => "VA", "Washington" => "WA", "West Virginia" => "WV", "Wisconsin" => "WI", "Wyoming" => "WY"
    );

    $users = get_users();
    foreach ($users as $user) {
        $user_id = $user->ID;

        // Update main account holder state
        $state = get_user_meta($user_id, 'state', true);
        if (array_key_exists($state, $state_abbreviations)) {
            update_user_meta($user_id, 'state', $state_abbreviations[$state]);
        }

        // Update dependents state
        $dependents = get_user_meta($user_id, 'dependent_member', true);
        if ($dependents && is_array($dependents)) {
            foreach ($dependents as &$dependent) {
                if (isset($dependent['state']) && array_key_exists($dependent['state'], $state_abbreviations)) {
                    $dependent['state'] = $state_abbreviations[$dependent['state']];
                }
            }
            update_user_meta($user_id, 'dependent_member', $dependents);
        }
    }
}
