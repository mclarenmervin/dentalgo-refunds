<?php
/**
 * Plugin Name: PMPro Refund Process
 * Description: A custom plugin to handle refunds in Paid Memberships Pro.
 * Version: 1.1
 * Author: Magnigenie
 * Text Domain: pmpro-refund-process
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if (!defined('PMPRO_REFUND_PROCESS_FILE')) {
    define('PMPRO_REFUND_PROCESS_FILE', __FILE__);
}

if (!defined('PMPRO_REFUND_PROCESS_VERSION')) {
    define('PMPRO_REFUND_PROCESS_VERSION', '1.0');
}

if (!defined('PMPRO_REFUND_PROCESS_PLUGIN_DIR')) {
    define('PMPRO_REFUND_PROCESS_PLUGIN_DIR', plugin_dir_path(PMPRO_REFUND_PROCESS_FILE));
}

if (!defined('PMPRO_REFUND_PROCESS_PLUGIN_URL')) {
    define('PMPRO_REFUND_PROCESS_PLUGIN_URL', plugin_dir_url(PMPRO_REFUND_PROCESS_FILE));
}

if (!defined('PMPRO_REFUND_PROCESS_BASE')) {
    define('PMPRO_REFUND_PROCESS_BASE', plugin_basename(PMPRO_REFUND_PROCESS_FILE));
}

// Include the setting class.
if (!class_exists('PMPro_Refund_Settings', false)) {
    include_once dirname(__FILE__) . '/admin/pmpro-refund-settings.php';
}

// Include the main PMPro_Refund_Function class.
if (!class_exists('PMPro_Refund_Function', false)) {
    include_once dirname(__FILE__) . '/includes/pmpro-refund-functions.php';
}