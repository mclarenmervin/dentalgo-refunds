jQuery(document).ready(function($) {
    var index = $('#state-area .w-row').length;
    
    $('#add-state').click(function() {
        index++;
        var newRow = `
            <div class="w-row">
                <div class="empty-col-left w-col w-col-4">
                    <label for="state${index}">Select state 
                        <span class="text-color-red">*</span>
                    </label>
                    <select id="state${index}" name="state[]" data-name="state" required="" class="select-pres select-field w-select">
                        <option value="">Select one...</option>
                        <option value="Alaska">Alaska</option>
                        <option value="Arkansas">Arkansas</option>
                        <option value="Colorado">Colorado</option>
                        <option value="Connecticut">Connecticut</option>
                        <option value="Delaware">Delaware</option>
                        <option value="Florida">Florida</option>
                        <option value="Illinois">Illinois</option>
                        <option value="Indiana">Indiana</option>
                        <option value="Kansas">Kansas</option>
                        <option value="Louisiana">Louisiana</option>
                        <option value="Maryland">Maryland</option>
                        <option value="Mississippi">Mississippi</option>
                        <option value="Missouri">Missouri</option>
                        <option value="Montana">Montana</option>
                        <option value="Nebraska">Nebraska</option>
                        <option value="Nevada">Nevada</option>
                        <option value="New Hampshire">New Hampshire</option>
                        <option value="New York">New York</option>
                        <option value="North Dakota">North Dakota</option>
                        <option value="Ohio">Ohio</option>
                        <option value="Oklahoma">Oklahoma</option>
                        <option value="Oregon">Oregon</option>
                        <option value="Rhode Island">Rhode Island</option>
                        <option value="South Carolina">South Carolina</option>
                        <option value="South Dakota">South Dakota</option>
                        <option value="Tennessee">Tennessee</option>
                        <option value="Texas">Texas</option>
                        <option value="Utah">Utah</option>
                        <option value="Vermont">Vermont</option>
                        <option value="Washington">Washington</option>
                        <option value="West Virginia">West Virginia</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Idaho">Idaho</option>
                        <option value="Kentucky">Kentucky</option>
                        <option value="Massachusetts">Massachusetts</option>
                        <option value="Minnesota">Minnesota</option>
                    </select>
                </div>
                <div class="empty-col-right w-col w-col-4">
                    <label for="trialperiod${index}">Trial Period
                        <span class="text-color-red">*</span>
                    </label>
                    <input type="number" id="trialperiod${index}" name="trialperiod[]" min="14" max="35" step="1" value="30" required="" class="input-dose select-field w-select">
                </div>
                <div class="empty-col-right w-col w-col-4">
                    <label for="refundtype<${index}">Refund Type
                        <span class="text-color-red">*</span>
                    </label>
                    <select id="refundtype<${index}" name="refundtype[]" data-name="refundtype" required="" class="select-dose select-field w-select">
                        <option value="">Select a Refund Type</option>
                        <option value="membershiponly">Membership Fees only</option>
                        <option value="totalamount">Membership Fees & (Partial) Enrolment Fees</option>
                    </select>
                </div>
                <div class="column-2 w-col w-col-4">
                    <label for="nonrefundableamount${index}">Non Refundable Amount
                        <span class="text-color-red">*</span>
                    </label>
                    <input type="text" id="nonrefundableamount${index}" name="nonrefundableamount[]" required="" class="input-nonrefundableamount select-field w-select">
                </div>
            </div>
        `;
        $('#state-area').append(newRow);
    });

    $('#remove-state').click(function() {
        if ($('#state-area .w-row').length > 1) {
            $('#state-area .w-row:last').remove();
        }
    });
});
