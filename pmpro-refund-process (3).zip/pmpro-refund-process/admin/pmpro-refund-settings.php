<?php

defined('ABSPATH') || exit;

class PMPro_Refund_Settings
{
    private $us_states = array(
        "AL" => "Alabama", "AK" => "Alaska", "AZ" => "Arizona", "AR" => "Arkansas", "CA" => "California",
        "CO" => "Colorado", "CT" => "Connecticut", "DE" => "Delaware", "FL" => "Florida", "GA" => "Georgia",
        "HI" => "Hawaii", "ID" => "Idaho", "IL" => "Illinois", "IN" => "Indiana", "IA" => "Iowa",
        "KS" => "Kansas", "KY" => "Kentucky", "LA" => "Louisiana", "ME" => "Maine", "MD" => "Maryland",
        "MA" => "Massachusetts", "MI" => "Michigan", "MN" => "Minnesota", "MS" => "Mississippi", "MO" => "Missouri",
        "MT" => "Montana", "NE" => "Nebraska", "NV" => "Nevada", "NH" => "New Hampshire", "NJ" => "New Jersey",
        "NM" => "New Mexico", "NY" => "New York", "NC" => "North Carolina", "ND" => "North Dakota", "OH" => "Ohio",
        "OK" => "Oklahoma", "OR" => "Oregon", "PA" => "Pennsylvania", "RI" => "Rhode Island", "SC" => "South Carolina",
        "SD" => "South Dakota", "TN" => "Tennessee", "TX" => "Texas", "UT" => "Utah", "VT" => "Vermont",
        "VA" => "Virginia", "WA" => "Washington", "WV" => "West Virginia", "WI" => "Wisconsin", "WY" => "Wyoming"
    );

    public function __construct()
    {
        add_action('admin_menu', array($this, 'register_menu_page'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_init', array($this, 'handle_form_submission'));
    }

    public function register_menu_page()
    {
        add_menu_page(
            __('DentalGo Refunds', 'pmpro-refund-process'),
            __('DentalGo Refunds', 'pmpro-refund-process'),
            'manage_options',
            'refund-settings',
            array($this, 'menu_page_content'),
            'dashicons-admin-settings',
            6
        );
    }

    public function menu_page_content()
    {
        $refund_logic = get_option('pmpro_refund_settings', array());
		$processingfee = get_option('processingfee', '');
        ?>
        <div class="wrap">
            <h1><?php _e('PMPro Refund Settings', 'pmpro-refund-process'); ?></h1>
            <section style="padding-top: 20px;">
                <div class="container">
                    <form id="wf-form-Sign-Up-Form" class="custom-form" name="wf-form-Sign-Up-Form" method="post" action="">
                        <?php wp_nonce_field('pmpro_refund_settings_save', 'pmpro_refund_settings_nonce'); ?>
                        <h3 class="_0-margin-top">State Info:</h3>
                        <p class="para-small">
                            <em>Add Logic For Calculating Refund And Time Period</em><br>
                        </p>
						<div>
							<div class="w-row">
								<div class="empty-col-right w-col w-col-4">
									<label for="processingfee">Processing Fee
										<span class="text-color-red">*</span>
									</label>
								</div>
								<div class="empty-col-right w-col w-col-4">
									<input type="number" id="processingfee" name="processingfee" value="<?php echo isset($processingfee) ? esc_attr($processingfee) : ''; ?>" step="1" class="input-dose select-field w-select" required>
								</div>
							</div>
						</div>
                        <div id="state-area">
                            <?php foreach ($this->us_states as $state_code => $state_name): ?>
                                <div class="w-row">
                                    <div class="empty-col-left w-col w-col-8">
                                        <label for="state_<?php echo $state_code; ?>">State: <?php echo $state_name; ?></label>
                                    </div>
                                    <div class="empty-col-right w-col w-col-4">
                                        <label for="trialperiod_<?php echo $state_code; ?>">Trial Period
                                            <span class="text-color-red">*</span>
                                        </label>
                                        <input type="number" id="trialperiod_<?php echo $state_code; ?>" name="trialperiod[<?php echo $state_code; ?>]" value="<?php echo isset($refund_logic[$state_code]['trialperiod']) ? esc_attr($refund_logic[$state_code]['trialperiod']) : ''; ?>" min="14" max="35" step="1" class="input-dose select-field w-select">
                                    </div>
                                    <div class="empty-col-right w-col w-col-4">
                                        <label for="refundtype_<?php echo $state_code; ?>">Refund Type
                                            <span class="text-color-red">*</span>
                                        </label>
                                        <select id="refundtype_<?php echo $state_code; ?>" name="refundtype[<?php echo $state_code; ?>]" data-name="refundtype" class="select-dose select-field w-select">
                                            <option value="">Select a Refund Type</option>
                                            <option value="membershiponly" <?php selected(isset($refund_logic[$state_code]['refundtype']) ? $refund_logic[$state_code]['refundtype'] : '', 'membershiponly'); ?>>Membership Fees Only</option>
                                            <option value="totalamount" <?php selected(isset($refund_logic[$state_code]['refundtype']) ? $refund_logic[$state_code]['refundtype'] : '', 'totalamount'); ?>>Membership Fees & (Partial) Enrolment Fees</option>
											<option value="norefund" <?php selected(isset($refund_logic[$state_code]['refundtype']) ? $refund_logic[$state_code]['refundtype'] : '', 'norefund'); ?>>No Refund</option>
                                        </select>
                                    </div>
                                    <div class="column-2 w-col w-col-4">
                                        <label for="nonrefundableamount_<?php echo $state_code; ?>">Non Refundable Amount
                                            <span class="text-color-red">*</span>
                                        </label>
                                        <input type="number" id="nonrefundableamount_<?php echo $state_code; ?>" name="nonrefundableamount[<?php echo $state_code; ?>]" value="<?php echo isset($refund_logic[$state_code]['nonrefundableamount']) ? esc_attr($refund_logic[$state_code]['nonrefundableamount']) : ''; ?>" min="0" max="50" step="1" class="input-nonrefundableamount select-field w-select">
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="submit" name="submit" value="<?php _e('Save Settings', 'pmpro-refund-process'); ?>" class="button button-primary">
                    </form>
                </div>
            </section>
        </div>
        <?php
    }
    
    public function enqueue_scripts($hook)
    {
        if ($hook != 'toplevel_page_refund-settings') {
            return;
        }

        // Enqueue jQuery (WordPress includes a built-in version of jQuery)
        wp_enqueue_script('jquery');

        // Enqueue custom JS
        wp_enqueue_script(
            'pmpro-refund-settings-js',
            plugin_dir_url(__FILE__) . 'js/pmpro-refund-settings.js',
            array('jquery'),
            null,
            true
        );

        // Enqueue custom CSS
        wp_enqueue_style(
            'pmpro-refund-settings-css',
            plugin_dir_url(__FILE__) . 'css/pmpro-refund-settings.css'
        );
    }

    public function handle_form_submission()
    {
        if (isset($_POST['pmpro_refund_settings_nonce']) && wp_verify_nonce($_POST['pmpro_refund_settings_nonce'], 'pmpro_refund_settings_save')) {
            if (isset($_POST['trialperiod']) && isset($_POST['refundtype']) && isset($_POST['nonrefundableamount'])) {
                $refund_logic = array();
    
                foreach ($this->us_states as $state_code => $state_name) {
                    if (isset($_POST['trialperiod'][$state_code]) && isset($_POST['refundtype'][$state_code]) && isset($_POST['nonrefundableamount'][$state_code])) {
                        $refund_logic[$state_code] = array(
                            'trialperiod' => sanitize_text_field($_POST['trialperiod'][$state_code]),
                            'refundtype' => sanitize_text_field($_POST['refundtype'][$state_code]),
                            'nonrefundableamount' => sanitize_text_field($_POST['nonrefundableamount'][$state_code]),
                        );
                    }
                }
    
                update_option('pmpro_refund_settings', $refund_logic);
            }
			if (isset($_POST['processingfee'])) {
				$processingfee = sanitize_text_field($_POST['processingfee']); // Sanitize the input
				update_option('processingfee', $processingfee); // Update the option in the database
			}
        }
    }
    
}

new PMPro_Refund_Settings();