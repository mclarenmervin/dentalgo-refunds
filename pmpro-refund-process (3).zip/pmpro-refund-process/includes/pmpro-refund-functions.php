<?php

defined('ABSPATH') || exit;

require 'vendor/autoload.php'; // Ensure this path is correct

class PMPro_Refund_Function
{
    private $state_policies = array(
        "AK" => "Enrollment Date",
        "AR" => "Effective Date",
        "CO" => "Enrollment Date",
        "CT" => "Enrollment Date",
        "DE" => "Upon Receipt of Card by Member",
        "FL" => "Effective Date",
        "IL" => "Upon Receipt of Card by Member",
        "IN" => "Upon Receipt of Card by Member",
        "KS" => "Enrollment Date",
        "LA" => "Upon receipt of written documents",
        "MD" => "Effective Date",
        "MS" => "Purchase of the plan",
        "MO" => "Upon Receipt of Card by Member",
        "MT" => "Upon Receipt of Card by Member",
        "NE" => "Upon receipt of written documents",
        "NV" => "",
        "NH" => "Upon receipt of written documents",
        "NY" => "Enrollment Date",
        "ND" => "Upon Receipt of Card by Member",
        "OH" => "Upon Receipt of Card by Member",
        "OK" => "Upon Receipt of Card by Member",
        "OR" => "the day following the date on which the member completed any application for the plan or the day following the date on which the member paid any fees…",
        "RI" => "Upon Receipt of Card by Member",
        "SC" => "Upon Receipt of Card by Member",
        "SD" => "Enrollment Date",
        "TN" => "Enrollment Date",
        "TX" => "Enrollment Date",
        "UT" => "Enrollment Date",
        "VT" => "Consumer gave express informed consent to be charged",
        "WA" => "Upon Receipt of written documents",
        "WV" => "Upon Receipt of Membership Material by Member"
    );

    public function __construct()
    {
        add_action('pmpro_after_change_membership_level', array($this, 'pmpro_after_expiration_change_membership_levels'), 10, 3);
        add_filter( 'pmpro_cancel_on_next_payment_date', array($this, 'pmpro_set_next_payment_date_false'), 10, 3);
    }

    public function get_pmpro_refund_settings()
    {
        return get_option('pmpro_refund_settings', array());
    }

    public function get_values_by_state_code($state_code)
    {
        $refund_settings = get_option('pmpro_refund_settings', array());

        if (array_key_exists($state_code, $refund_settings)) {
            return $refund_settings[$state_code];
        }

        return null; // Return null if no settings found for the state code
    }

    private function parse_effective_date($date_str)
    {
        if (preg_match('/^(\d{2})(\d{2})(\d{4})$/', $date_str, $matches)) {
            $month = $matches[1];
            $day = $matches[2];
            $year = $matches[3];
            return new DateTime("$year-$month-$day");
        }
        return false;
    }

    // public function mg_send_refund_success_mail($charge_id, $refund_id, $refund_amount, $refundtype, $user_id, $cancel_level_id) {

    //     global $wpdb;
    //     $user       = get_user_by( 'id', $user_id );
    //     $sitename   = get_option( 'blogname' );
	// 	$siteemail  = get_option('pmpro_from_email');
    //     $email      = $user->user_email;
    //     $from       = get_bloginfo("admin_email");
    //     $fromname   = 'Dentalgo';

    //     $subject = sprintf(__('Your membership at %s has been CANCELLED', 'paid-memberships-pro'), $sitename);
    //     $body = '<p>Your DentalGo payment subscription has been cancelled.</p>';
    //     $body .= '<p>Account: '.$email.'</p>';
    //     $body .= '<p>DentalGo Plan ID: '.$cancel_level_id.'</p>';
    //     $body .= '</br><p><strong>Refund Status</strong></p>';
    //     $body .= '<p><strong>Refund : '.$refundtype.'</strong></p>';
    //     $body .= '<p><strong>Refund Amount: '.$refund_amount.'</strong></p>';
    //     $body .= '<p><strong>Refund ID: '.$refund_id.'</strong></p>';
    //     $body .= '<p><strong>Order ID: '.$charge_id.'</strong></p>';

    //     $data['body'] = $body;

    //     $template =  array(
    //                 'subject' => __( "Your payment subscription at !!sitename!! has been CANCELLED", 'paid-memberships-pro' ),
    //                 'description' => __('Cancelation Refund', 'paid-memberships-pro'),
    //                 'body' => __( '<p>Your payment subscription at !!sitename!! has been cancelled.</p>
            
    //         <p>Account: !!display_name!! (!!user_email!!)</p>
    //         <p>Membership Level: !!membership_level_name!!</p>
    //         <p>Your access will expire on !!enddate!!.</p>', 'paid-memberships-pro' ),
    //                 'help_text' => __( 'When a user cancels a membership with a recurring subscription, they will still have access until when their next payment would have been taken. This email is sent to the member to notify them of this change.', 'paid-memberships-pro' )
    //             );


    //     $email_header = pmpro_email_templates_get_template_body( 'header' );
    //     $email_footer = pmpro_email_templates_get_template_body( 'footer' );

    //     $body = $email_header . $body . $email_footer;

    //     wp_mail($email,$subject,$body,$headers);

    //     // $membership_level_name = pmpro_implodeToEnglish($wpdb->get_col("SELECT name FROM $wpdb->pmpro_membership_levels WHERE id IN('" . implode("','", $cancel_level_id) . "')"));
    //     // $enddate    = $wpdb->get_var("SELECT UNIX_TIMESTAMP(CONVERT_TZ(enddate, '+00:00', @@global.time_zone)) as enddate FROM $wpdb->pmpro_memberships_users WHERE user_id = '" . $user->ID . "' AND membership_id = '" . $cancel_level_id . "' AND status IN('inactive', 'cancelled', 'admin_cancelled') ORDER BY id DESC");
        
    //     // print_r('<pre>');
    //     // print_r($wpdb->pmpro_membership_levels);
    //     // print_r($user);
    //     // print_r($cancel_level_id);
    //     // print_r('sitename: '. $sitename);
    //     // print_r('siteemail: '. $siteemail);
    //     // print_r('membership_level_name: '. $membership_level_name);
    //     // print_r('enddate: '. $enddate);
    //     // exit;
    //     // mg_send_refund_email($user);
    //     // mg_send_admin_refund_email($user);
    //     // $myemail = new PMProEmail();
	//     // $myemail->sendEmail($email, $from, $fromname, $subject, '', $data);
       
    // }

    public function mg_pmpro_get_trail_end_date( $user_id, $order ) {
        $state = get_user_meta($user_id, 'pmpro_bstate', true);
        $effectivedate_str = get_user_meta($user_id, 'pmpro_effectivedate', true);

        $order_date_str = $order->timestamp;
        $order_date     = (new DateTime())->setTimestamp($order_date_str);
        $effectivedate  = $this->parse_effective_date($effectivedate_str);

        if ( !empty($state) ) {

            $values = $this->get_values_by_state_code($state);

            if ($values !== null) {
                $trialperiod = $values['trialperiod'];
            }

            if ($this->state_policies[$state] == 'Enrollment Date') {
                $start_date = $order_date;
            } elseif ($this->state_policies[$state] == 'Effective Date' && $effectivedate) {
                $start_date = $effectivedate;
            } else {
                // Handle other policies if needed
                $start_date = $order_date;
            }

            $trial_period_end_date = (clone $start_date)->modify("+$trialperiod days");
            return $trial_period_end_date;
        }
        return '';
    }

    public function mg_pmpro_refund( $user, $last_order, $refund_amount, $charge_id) {
        $stripe_sandbox_sk = get_option('pmpro_sandbox_stripe_connect_secretkey');
        $stripe_live_sk = get_option('pmpro_live_stripe_connect_secretkey');
        $pmpro_gateway_environment = get_option('pmpro_gateway_environment');

        if ($pmpro_gateway_environment == 'sandbox') {
            \Stripe\Stripe::setApiKey($stripe_sandbox_sk);
        } else {
            \Stripe\Stripe::setApiKey($stripe_live_sk);
        }
        try {
            $refund = \Stripe\Refund::create([
                'charge' => $charge_id,
                'amount' => $refund_amount * 100, // amount in cents
            ]);

            if ( $refund->status != 'failed' ) {

                update_user_meta($user->ID, 'mg_refunded_amount', $refund_amount);
                //send an email to the member
                $myemail = new PMProEmail();
                $myemail->sendRefundedEmail( $user, $last_order );

                //send an email to the admin
                $myemail = new PMProEmail();
                $myemail->sendRefundedAdminEmail( $user, $last_order );

                $last_order->status = 'refunded';
				$last_order->saveOrder();
            }
			
            // $this->mg_send_refund_success_mail( $charge_id, $refund->id, $refund_amount, $refundtype, $user_id, $cancel_level_id );
            // echo "Refund successful. Refund ID: " . $refund->id;
        } catch (\Stripe\Exception\ApiErrorException $e) {
            // Handle error
            // echo "Refund failed: " . $e->getMessage();
        }
    }

    public function pmpro_after_expiration_change_membership_levels($level_id, $user_id, $cancel_level_id)
    {
        if (0 === $level_id) {
            // Get the last order for the user
            $last_order = new MemberOrder();
            $last_order->getLastMemberOrder($user_id);
            $user = get_user_by( 'id', $user_id );
			$processingfee = get_option('processingfee', 0);
			
            if (!empty($last_order->id)) {

                $trail_end_date = $this->mg_pmpro_get_trail_end_date( $user_id, $last_order );
                $order_total = $last_order->total;
                $charge_id = $last_order->payment_transaction_id;

                $state  = get_user_meta($user_id, 'pmpro_bstate', true);
                $values = $this->get_values_by_state_code($state);

                if ($values !== null) {
                    $refundtype = $values['refundtype'];
                    $nonrefundableamount = $values['nonrefundableamount'];

                    $refund_amount = $order_total;
                    $current_date = new DateTime();

                    if ($current_date < $trail_end_date) {
                        
                        if ($refundtype == 'membershiponly') {
                            $refund_amount -= $processingfee;
							$refund_amount = max($refund_amount, 0);
							$this->mg_pmpro_refund( $user, $last_order, $refund_amount, $charge_id);
                        }
                        elseif ($refundtype == 'totalamount') {
							if($nonrefundableamount){
                            	$refund_amount -= $nonrefundableamount;
							}
							$refund_amount = max($refund_amount, 0);
							$this->mg_pmpro_refund( $user, $last_order, $refund_amount, $charge_id);
                        } 
						elseif ($refundtype == 'norefund') {
							
							// Retrieve the last order for the user
							$last_order = new MemberOrder();
							$last_order->getLastMemberOrder($user_id);
							$membership_level = new PMPro_Membership_Level($last_order->membership_id);
							
							$this->adminmembershipcancelemail($user_id, $last_order, $membership_level);
							$this->usermembershipcancelemail($user_id, $last_order, $membership_level);
						}
                    } else {
						// Retrieve the last order for the user
						$last_order = new MemberOrder();
						$last_order->getLastMemberOrder($user_id);
						$membership_level = new PMPro_Membership_Level($last_order->membership_id);

						$this->adminmembershipcancelemail($user_id, $last_order, $membership_level);
						$this->usermembershipcancelemail($user_id, $last_order, $membership_level);
					}
                }
            }
        }
    }
	
    public function pmpro_set_next_payment_date_false( $return, $old_lavel, $user_id ) {
        $last_order = new MemberOrder();
        $last_order->getLastMemberOrder($user_id);

        $trail_end_date = $this->mg_pmpro_get_trail_end_date( $user_id, $last_order );
        $current_date = new DateTime();

        if ($current_date < $trail_end_date) {
            return false;
        }
        else {
            return $return;
        }
    }
	
	public function usermembershipcancelemail($user_id, $last_order, $membership_level){
		// Retrieve the user object
		$user = get_user_by('id', $user_id);

		if ($user && $last_order) {
			// Set the order status to 'canceled' before sending emails
			$last_order->status = 'canceled';
			$last_order->saveOrder();
			
			// Define dynamic data
			$account_email = $user->user_email;
			$plan_name = $membership_level->name;
			$refund_amount = pmpro_formatPrice($last_order->total); // Assuming refund amount is the order total
			$refund_status = $last_order->status; // You can change this depending on the refund logic
			$access_expiration_date = date('m/d/Y', strtotime('+1 month')); // Example expiration date logic

			// Build the email content for the user
			$user_subject = sprintf(__('Your payment subscription at %s has been CANCELLED', 'pmpro'), get_bloginfo('name'));
			$user_message = '
								<div style="background:#FAFAFA;padding:15px;text-align:center">
									<table style="background:#FAFAFA;margin:0px" align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
										<tr>
											<td align="center" valign="top">
												<table border="0" cellpadding="0" cellspacing="0" style="background:#FFFFFF;border-top:0px solid #DDDDDD;border-bottom:0px solid #DDDDDD;margin:0px;text-align:left;width:100%">
													<tr>
														<td style="border:none;padding:20px" align="left" valign="top">
															<a href="' . home_url() . '" title="' . get_bloginfo('name') . '" target="_blank">
																<img alt="' . get_bloginfo('name') . '" src="https://dgostaging.wpenginepowered.com/wp-content/uploads/dg-email-logo@2x.png" style="max-height:80px;padding-bottom:0" />
															</a>
														</td>
													</tr>
													<tr>
														<td align="left" valign="top" style="background:#FFFFFF;border:none;font-family:Arial,sans-serif;font-size:15px;line-height:23px;padding:0px 20px 0px 20px;text-align:left">
															<div style="text-align:left;padding:20px 0px 20px 0px;border-bottom:1px solid #DDDDDD;border-top:1px solid #DDDDDD">
																<p>' . __('Your DentalGo payment subscription has been cancelled.', 'pmpro') . '</p>
																<p>' . __('Account:', 'pmpro') . ' ' . $account_email . '</p>
																<p>' . __('DentalGo Plan:', 'pmpro') . ' ' . $plan_name . '</p>
																<p>' . __('Refund Status: not eligible', 'pmpro') . '</p>
															</div>
														</td>
													</tr>
													<tr>
														<td valign="top" style="border:none;color:#888888;font-family:Arial,sans-serif;font-size:13px;line-height:22px;padding:20px;text-align:left">
															<p style="margin:0px;padding:0px">© 2024 <a style="color:#888888;font-weight:bold;text-decoration:none" href="' . home_url() . '">' . get_bloginfo('name') . '</a></p>
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
								</div>';

			// Send the cancellation email to the user using wp_mail
			wp_mail($user->user_email, $user_subject, $user_message, array('Content-Type: text/html; charset=UTF-8'));

		}
	}
	
	public function adminmembershipcancelemail($user_id, $last_order, $membership_level) {
		
		// Retrieve the user object
		$user = get_user_by('id', $user_id);

		if ($user && $last_order) {
			// Set the order status to 'canceled' before sending emails
			$last_order->status = 'canceled';
			$last_order->saveOrder();

			// Define dynamic data
			$account_email = $user->user_email;
			$plan_name = $membership_level->name;
			$refund_eligibility_state = 'Alaska'; // Use dynamic data for the state if needed
			$timestamp = $last_order->timestamp;
			$registration_date = date('m/d/Y', $timestamp); // Example registration date logic

			// Build the email content for the admin
			$admin_subject = sprintf(__('Membership for %s at DentalGo has been CANCELLED', 'pmpro'), $account_email);

			$admin_message = '
								<div style="background:#FAFAFA;padding:15px;text-align:center">
									<table style="background:#FAFAFA;margin:0px" align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
										<tr>
											<td align="center" valign="top">
												<table border="0" cellpadding="0" cellspacing="0" style="background:#FFFFFF;border-top:0px solid #DDDDDD;border-bottom:0px solid #DDDDDD;margin:0px;text-align:left;width:100%">
													<tr>
														<td style="border:none;padding:20px" align="left" valign="top">
															<a href="' . home_url() . '" title="' . get_bloginfo('name') . '" target="_blank">
																<img alt="' . get_bloginfo('name') . '" src="https://dgostaging.wpenginepowered.com/wp-content/uploads/dg-email-logo@2x.png" style="max-height:80px;padding-bottom:0" />
															</a>
														</td>
													</tr>
													<tr>
														<td align="left" valign="top" style="background:#FFFFFF;border:none;font-family:Arial,sans-serif;font-size:15px;line-height:23px;padding:0px 20px 0px 20px;text-align:left">
															<div style="text-align:left;padding:20px 0px 20px 0px;border-bottom:1px solid #DDDDDD;border-top:1px solid #DDDDDD">
																<p>' . __('The membership for', 'pmpro') . ' ' . $account_email . ' ' . __('at DentalGo has been cancelled.', 'pmpro') . '</p>
																<p>' . __('Account:', 'pmpro') . ' ' . $account_email . '</p>
																<p>' . __('Membership Level:', 'pmpro') . ' ' . $plan_name . '</p>
																<p><strong>' . __('Refund Eligibility:', 'pmpro') . '</strong></p>
																<p>' . __('State:', 'pmpro') . ' ' . $refund_eligibility_state . '<br>
																' . __('Date of Registration:', 'pmpro') . ' ' . $registration_date . '</p>
																<p>' . __('Log in to your WordPress admin here:', 'pmpro') . ' <a href="' . wp_login_url() . '" target="_blank">' . wp_login_url() . '</a></p>
															</div>
														</td>
													</tr>
													<tr>
														<td valign="top" style="border:none;color:#888888;font-family:Arial,sans-serif;font-size:13px;line-height:22px;padding:20px;text-align:left">
															<p style="margin:0px;padding:0px">© 2024 <a style="color:#888888;font-weight:bold;text-decoration:none" href="' . home_url() . '">' . get_bloginfo('name') . '</a></p>
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
								</div>';

			// Send the cancellation email to the admin using wp_mail
			wp_mail(get_option('admin_email'), $admin_subject, $admin_message, array('Content-Type: text/html; charset=UTF-8'));
		}
	}

}

new PMPro_Refund_Function();